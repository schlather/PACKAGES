
/* 
 Authors
 Martin Schlather, schlather@math.uni-mannheim.de

 library for simulation of random fields 

 Copyright (C) 20017 -- 2017 Martin Schlather, 

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.
RO
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

//#include <R.h>
//#include <Rdefines.h>
//#include <R_ext/Linpack.h>
//#include <Rmath.h>  
//#include <stdio.h>  
//#include <unistd.h>
//#include <string.h>
//#include "RF.h"
//#include "primitive.h"
//#include "kleinkram.h"
// #include "Operator.h"
#include "RF.h"

#define ADD(ELT) SET_VECTOR_ELT(sublist, k++, ELT)
#define ADDCHAR(ELT) x[0] = ELT; ADD(ScalarString(mkChar(x)))


#define nOptimVar 4
const char * OPTIM_VAR_NAMES[nOptimVar] = 
  {"never", "respect bounds", "try", "yes"}; // keep yes last !!

/*
void ResetWarnings(int * allwarnings, int *local) {
  if (parallel() && !local) 
     ERR("Warnings may not be reset from a parallel process.");        
  messages_options *w = local ? KEYT() : &(GLO BAL.messages);
  w->warn_oldstyle = w->help_newstyle = w->warn_Aniso = 
    w->help_normal_mode = w->warn_mode =
    w->warn_on_grid = w->note_no_fit = w->note_aspect_ratio = 
    w->warn_coord_change = w->help_color_palette = w->warn_zenit =
    w->warn_constant = w->warn_negvar = w->help_onlyvar = w->note_no_fit =
    = w->help_mle = 
    w->warn_raw_covariates = w->help_addNA = w->help_help =
    w->warn_ambiguous = true;
  w->warn_mathdef = Nan;
  w->note_coordinates = w->note_detection = w->warn_seed = NOTE_WITH_HINT;
  if (*allwarnings) w->note_ambiguous = true;
}
*/


#define startmode normal
#define NM ((int) startmode)   /* normal mode */
//       {careless, sloppy, easygoing, normal, precise, pedantic, neurotic}
bool
  skipchecks[nr_modes] =  {true, false, false, false, false, false, false},
  ce_force[nr_modes] =       {true, true, true, false, false, false, false},
  ce_dependent[nr_modes] =   {true, true, true, false, false, false, false},
  sp_grid[nr_modes] =           {true, true, true, true, true, false, false},
  fit_reoptimise[nr_modes] = {false, false, false, false, true, true, true},
  fit_ratiotest_approx[nr_modes]={true, true, true, true, false, false, false},
  fit_cross_refit[nr_modes] = {false, false, false, false, true, true, true}
  ;
char pch[nr_modes] =         {'\0',  '\0',  '\0',  '.',   '.',   '.',   '.'}
  ;
int locmaxn[nr_modes] =      {3000, 4000, 6000, 8000, 9000, 10000000, 10000000},
  ce_trials[nr_modes] =      {1,    2,    3,    3,    4,    5,   6},
  spectral_lines[nr_modes] = {300, 500, 1500,  2500, 3500, 5000, 10000},
  tbm_lines[nr_modes] =      {30,   40,   50,   60,   80,   100,   200},
  mpp_n_estim_E[nr_modes] =  {10000, 10000, 20000,50000,80000,100000,1000000},
  hyper_superpos[nr_modes] = {200, 300, 450, 700, 1000, 2000, 5000},
  maxclique[nr_modes] =      {1000, 2000, 3500, 5000, 6000, 7000, 10000000},
  fit_critical[nr_modes] =   {-1,  -1,   -1,   0,   1,   2,   3}, 
  fit_ncrit[nr_modes] =      { 2,   4,    5,   5,   5,  10,  20}, 
  //  fit_optim_var[nr_modes] =  { 2,   2,    2,   2,   1,   1,   1} ,
  fit_split[nr_modes] =      {10000,  5,  4, 4, 4, 3, 3},
  sequ_back_initial[nr_modes]={3,   3,    5,  10,  20,  30,  40}
  ;

usr_bool exactness[nr_modes] = {False, False, False, Nan, True, True, True};

double 
  ce_tolRe[nr_modes] =       {-1e2,  -1e1,  -1e-3, -1e-7,  -1e-14, 0, 0},
  ce_tolIm[nr_modes] =       {1e2,  1e1,  1e-1,  1e-3,   1e-7, 0, 0},
  ce_approx_step[nr_modes] = {1.0,  1.0,   RF_NA, RF_NA, RF_NA, 0.0, 0.0},
#ifdef SCHLATHERS_MACHINE
  svd_tol[nr_modes] =     {1e-5, 1e-6, 1e-7, 1e-8, 1e-10, 1e-12, 0},
#else
  svd_tol[nr_modes] =     {0, 0, 0, 0, 0, 0, 0},
#endif
  nugget_tol[nr_modes] =     {1e-8, 1e-8, 1e-12, 0,     0,     0,     0},
  tbm_linefactor[nr_modes] = {1.5,  1.5,  1.7,   2.0,  3.0,  5.0,  6.0},
  mpp_intensity[nr_modes] =  {50, 50, 80, 100, 200, 500, 1000},
  mpp_zero[nr_modes] =       {1e-2, 1e-2, 1e-3, 1e-4, 1e-5, 1e-6, 1e-7},
  max_max_gauss[nr_modes] =  {2,    2,    3,    4,    5,   6,   6},
  fit_pgtol[nr_modes]       ={10, 1e-2, 1e-3, 1e-4, 1e-4, 1e-6, 0},
  fit_pgtol_recall[nr_modes]={10, 1e-1, 1e-2, 1e-3, 1e-3, 1e-4, 0},
  fit_factr[nr_modes]       ={1e14, 1e13, 1e12, 1e11, 1e11, 1e9, 1e7},
  fit_factr_recall[nr_modes]={1e15, 1e14, 1e13, 1e12, 1e12, 1e10, 1e8}
   ;

const char *f_opt[nr_modes] = {"optim", "optim", "optim", "optim", "optim", "optim", "optim"}; // to do optimx


option_type OPTIONS = {
  general_START,
  gauss_START,
  krige_START, 
  ce_START,
  spectral_START,
   tbm_START,
  direct_START,
  sequ_START,
  ave_START,
  nugget_START,
  mpp_START,

  hyper_START,
  extreme_START,
  br_START,
  distr_START,
  {fit_START}, 
  
  empvario_START, 
  gui_START,  
  graphics_START,
  register_START,
  internal_START,
  messages_START,
  {coords_START}, 
  special_START

};   
  

void SetDefaultOutputModeValues(output_modes mode, bool local){
  if (!local && parallel())
    ERR("global options may be set only by RFoptions()");

  // printf("hier: mode=%d %d\n", mode, local);
  
  general_options *gp = &(OPTIONS.general);
  if (local) {
    KEY_type * KT = KEYT();
    gp = &(KT->global.general);
   }
  gp->output = mode;
  gp->sp_conform = mode == output_sp;
  gp->returncall = mode == output_geor;
  gp->reportcoord = 
    mode == output_geor ? reportcoord_always : reportcoord_warnings;
  /*
  switch(mode) {
  case output_sp : 
     break;
  case output_rf :
  break;
  case output_geor :
     break;
  default: BUG;
  }
  */
}


void SetDefaultModeValues(int old, int m, bool local){
  //                      high  fast, normal, save, pedantic
  if (!local && parallel())
    ERR("global options may be set only by RFoptions()");
  KEY_type * KT = KEYT();
  utilsoption_type *global_utils = local ? &(KT->global_utils) : OPTIONS_UTILS;
  option_type *global = local ? &(KT->global) : &OPTIONS;
  
			      
  global_utils->basic.skipchecks = skipchecks[m];
  global->general.pch = pch[m];
  global->general.exactness = exactness[m];
  global->krige.locmaxn = locmaxn[m];
  global->krige.locsplitn[NEIGHB_MIN]  = MINSPLITN(locmaxn[m]);
  global->krige.locsplitn[NEIGHB_SPLIT]  = MEDSPLITN(locmaxn[m]);
  global->krige.locsplitn[NEIGHB_MAX]  = MAXSPLITN(locmaxn[m]);
  global->ce.force = ce_force[m];
  global->ce.tol_im = ce_tolIm[m];
  global->ce.tol_re = ce_tolRe[m];
  global->ce.trials = ce_trials[m];
  global->ce.dependent = ce_dependent[m];
  global->ce.approx_grid_step = ce_approx_step[m];
  global_utils->solve.svd_tol = svd_tol[m];
  global->nugget.tol = nugget_tol[m];
  for(int i=0; i<4; global->spectral.lines[i++] = spectral_lines[m]);
  global->spectral.grid = sp_grid[m];
  global->tbm.lines[1] = tbm_lines[m];
  global->tbm.lines[2] = (tbm_lines[m] * 25) / 6;
  global->tbm.linesimufactor = tbm_linefactor[m];
  global->tbm.grid = sp_grid[m];
  global->mpp.n_estim_E = mpp_n_estim_E[m];
  for(int i=0; i<4; global->mpp.intensity[i++] = mpp_intensity[m]);
  global->mpp.about_zero = mpp_zero[m];
  global->hyper.superpos = hyper_superpos[m];
  global->extreme.standardmax = max_max_gauss[m];
  global->fit.locmaxn = maxclique[m];
  global->fit.locsplitn[NEIGHB_MIN] = MINCLIQUE(maxclique[m]);
  global->fit.locsplitn[NEIGHB_MED] = MEDCLIQUE(maxclique[m]);
  global->fit.locsplitn[NEIGHB_MAX] = MAXCLIQUE(maxclique[m]);
  fit_options *f = &(global->fit);
  f->split = fit_split[m];
  f->reoptimise = fit_reoptimise[m];
  f->ratiotest_approx = fit_ratiotest_approx[m];
  f->cross_refit = fit_cross_refit[m];
  f->critical = fit_critical[m];
  f->n_crit = fit_ncrit[m];
  f->pgtol = fit_pgtol[m];
  f->pgtol_recall = fit_pgtol_recall[m];
  f->factr = fit_factr[m];
  f->factr_recall = fit_factr_recall[m];
  //  f->optim_var_estim = fit_optim_var[m];
   char dummy[10];
  STRCPY(dummy, f_opt[m]);
  f->suboptimiser = f->optimiser = Match(dummy, OPTIMISER_NAMES, nOptimiser);
  global->sequ.initial = -(global->sequ.back = sequ_back_initial[m]);

  //  printf("optimiser %d %s\n", f->optimiser,  OPTIMISER_NAMES[f->optimiser]);

  messages_options *w = &(global->messages);
  if (m < normal) {
    w->warn_Aniso = w->note_ambiguous =  w->warn_ambiguous = 
      w->warn_on_grid = w->note_aspect_ratio = w->help_color_palette = false;
    w->warn_mathdef = False;
  } else if (m>old) { 
    w->warn_oldstyle = w->warn_Aniso = w->note_no_fit = 
      w->note_aspect_ratio = true;
    w->warn_mathdef = Nan;
    if (m > normal) w->note_ambiguous = w->warn_negvar = true;
  }
  if (m != normal && w->warn_mode) {
    // hier:  Syscall param sched_setaffinity(mask) points to unaddressable byte
     PRINTF("Note that the option '%s' is still in an experimental stage, so that the behaviour may change (slightly) in future.\n", general[GENERAL_MODUS]);
    w->warn_mode = false;
  }
}
 

void getUnits(SEXP el, char VARIABLE_IS_NOT_USED *name, 
	      char units[MAXCOORDNAMES][MAXUNITSCHAR], 
	      char units2[MAXCOORDNAMES][MAXUNITSCHAR]) {  
  int i, j, 
    l = length(el);
  if (TYPEOF(el) != NILSXP && TYPEOF(el) == STRSXP && l >= 1) {
    for (i=j=0; i<MAXCOORDNAMES; i++, j=(j + 1) % l) {
      strcopyN(units[i], CHAR(STRING_ELT(el, j)), MAXUNITSCHAR);
      if (units2!=NULL) {
	strcopyN(units2[i], CHAR(STRING_ELT(el, j)), MAXUNITSCHAR);
      }
    }
  } else RFERROR("invalid units");
}


SEXP UNITS(char units[MAXCOORDNAMES][MAXUNITSCHAR]) {
  SEXP unitnames;
  int nn;
  PROTECT(unitnames = allocVector(STRSXP, MAXCOORDNAMES)); 
  for (nn=0; nn<MAXCOORDNAMES; nn++) {
    SET_STRING_ELT(unitnames, nn, mkChar(units[nn]));
  }
  UNPROTECT(1);
  return unitnames;
}


void CE_set(SEXP el, int j, char *name, ce_options *cp, bool isList) {
  switch(j) {
  case 0: cp->force = LOGI; break;
  case 1:
    Real(el, name, cp->mmin, MAXCEDIM) ;
    int d;
    for (d=0; d<MAXCEDIM; d++) {
      if (cp->mmin[d]<0.0) {
	if ((cp->mmin[d]>-1.0)) {
	  cp->mmin[d] = - 1.0;
	  WARN1("'%.50s' set to -1.0.\n", name);
	}
      }
    }
    break;
  case 2: int strat;
    strat = INT;
    if (strat>LASTSTRATEGY) {  
      WARN2("%.50s <= %d not satisfied\n", name, LASTSTRATEGY);
    } else cp->strategy= (char) strat;          
    break;
  case 3: {
    cp->maxGB = POSNUM;
    if (!isList) cp->maxmem = MAXINT;	
  } break;
  case 4: {
    cp->maxmem = POSINT;  
    if (!isList) cp->maxGB = RF_INF;	
  }  break;
  case 5: cp->tol_im = POS0NUM; break;
  case 6: cp->tol_re = NEG0NUM; break;
  case 7: cp->trials = NUM;
    if (cp->trials<1) {
      cp->trials=1;
      WARN1("%.50s is set to 1\n", name);
    }
    break;
  case 8: cp->useprimes = LOGI; break;
  case 9: cp->dependent = LOGI; break;
  case 10: cp->approx_grid_step = POS0NUM; break;
  case 11: cp->maxgridsize = POS0INT; break;
  default: RFERROR("unknown parameter for 'RFoptions', section 'general'");
  }
}
 

 
const char * prefixlist[prefixN] = 
  {"general", "gauss", "krige", 
   "circulant", "direct",  "nugget",
   "sequ",
   "spectral", "tbm",
   "mpp", "hyper", "maxstable",  // 11
   "br", "distr", "fit",         // 14
   "empvario", "gui", "graphics",// 17 
   "registers", "internal", "messages", "coords", // 20
   "special", OBSOLETENAME, "ignore"  // 24
};


// IMPORTANT: all names of general has at least 3 letters  !!!
const char *general[generalN] =
  { "modus_operandi", "storing", "every", "gridtolerance", // 3
    "pch", "practicalrange", // 5
    "spConform", // influences output
    "exactness", "duplicated_locations", "na_rm_lines",
    "vdim_close_together", "expected_number_simu", // 11
    "detailed_output", "Ttriple",
    "returncall",
    "output", // influences spConform
    "reportcoord", "set", // 17
    "seed_incr", "seed_sub_incr"
};


const char *gauss[gaussN]= {"paired", "stationary_only", "approx_zero", 
			    "direct_bestvar", "loggauss", "boxcox"};

const char *krige[krigeN] = { "return_variance", "locmaxn",
			      "locsplitn", "locsplitfactor", "fillall"};

const char *CE[CEN] = {"force", "mmin", "strategy", "maxGB",
		       "maxmem", "tolIm","tolRe", 
		       "trials", "useprimes", "dependent", 
		       "approx_step", "approx_maxgrid"};

const char *direct[directN] = {//"root_method", "svdtolerance", 
			       "max_variab"};

const char * pnugget[pnuggetN] ={"tol"};

const char * sequ[sequN] ={"back_steps", "initial"};

const char * spectral[spectralN] = {"sp_lines", "sp_grid",  
				    "prop_factor", "sigma"};

const char * pTBM[pTBMN] = {"reduceddim", "fulldim", "center", 
			    "points", "lines", "linessimufactor", 
			    "linesimustep", "layers", "grid"};

const char * mpp[mppN] = {"n_estim_E", // n to determine E by simulation
			  "intensity", 
			  // "refradius_factor", 
			  "about_zero", "shape_power",
			  "scatter_max", "scatter_step",
			  // "plus", 
			  // "samplingdist", "samplingr",// MPP_cc
			  //"p", // Gneiting_cc
                         };

const char * hyper[hyperN] = {"superpos", "maxlines", "mar_distr",
			      "mar_options"};

const char * extreme[extremeN] = 
  {"max_gauss", "maxpoints", "xi",
   "density_ratio", "check_every", "flathull",
   "min_n_zhou", "max_n_zhou", "eps_zhou",
   "mcmc_zhou", "min_shape_gumbel", "scatter_method"};

const char * br[brN] = 
  {"maxtrendmem", "meshsize", 
   "vertnumber", "optim_mixed", "optim_mixed_tol", 
   "variobound", "deltaAM"};

const char * distr[distrN] = 
  {"safety", "minsteplen", "maxsteps", 
   "parts", "maxit",  "innermin", 
   "outermax", "mcmc_n", "repetitions"};

const char * fit[fitN] = 
  {"bin_dist_factor", "upperbound_scale_factor", "lowerbound_scale_factor", //2
   "lowerbound_scale_ls_factor","upperbound_var_factor","lowerbound_var_factor",
   //"lowerbound_sill",
   "scale_max_relative_factor", "minbounddistance", "minboundreldist",  //8
   "approximate_functioncalls",  "boxcox_lb",  "boxcox_ub", //11
   "use_naturalscaling", "only_users", //17
   "shortnamelength",  "split",   "scale_ratio", //20
   "critical",  "n_crit",  "max_neighbours",  //23
   "cliquesize",  "splitfactor_neighbours",  "smalldataset", 
   "min_diag",  "reoptimise",   "optimiser",
   "nloptr_algorithm",  "likelihood",  "ratiotest_approx", 
   "split_refined",  "cross_refit",  "estimate_variance_globally", 
   "pgtol", "pgtol_recall",  "factr",
   "factr_recall" ,
   "addNAlintrend", "emp_alpha", "suggesting_bounds", "trace",
   "sub_optimiser", "return_hessian", "standardizedL"
  };


const char * empvario[empvarioN] = 
  {"phi0", "theta0", "tol0", "fft", "halvenangles",
   "bins",  "nphi", "ntheta", "deltaT"};

const char * gui[guiN] = 
  {"alwaysSimulate", "simu_method", "size"};



const char *graphics[graphicsN]= 
  {"close_screen","grPrintlevel","height","increase_upto","always_open_device",
   "file", "onefile", "filenumber", "resolution", "split_screen",
   "width", "always_close_device", "grDefault", "xlim", "maxchar",
   "n_points"};

const char *registers[registersN] = 
  {"register", "predict_register", "likelihood_register"};

const char * internals[internalN] =  {
  "do_tests", "examples_reduced"};

const char * messages[messagesN] =  {
  // Achtung ! warn parameter werden nicht pauschal zurueckgesetzt
  "warn_oldstyle", "help_newstyle", "warn_newAniso", 
  "note_ambiguous", "help_normal_mode", 
  "warn_mode", // internal --- not documented in RFoptions!
   "warn_scale", "note_coordinates", "warn_on_grid",
  
  "note_no_fit", "note_aspect_ratio", "warn_coord_change",
  "help_colour_palette", "warn_missing_zenit",
   "warn_constant", "warn_negvar", "help_onlyvar",
  "warn_mathdef", // internal --- not documented in RFoptions!
  
  "warn_seed", "warn_modus_operandi", // 17.11.20 to be deleted in near future
  "warn_singlevariab", "help_mle", "note_detection",
  "warn_raw_covariates", "help_addNA", "help_help", "warn_ambiguous",
  "vec_len",// name in str(),
  "warn_examples_reduced"
};

const char *coords[coordsN] =
  { "xyz_notation", "coord_system", "new_coordunits", "coordunits", "varunits",
    "varidx", "varnames", "coordidx", "coordnames", "new_coord_system",
    "zenit", // "radius",
    "polar_coord", "angleunits", "allow_earth2cart",
    "dataframe_initial", "coord_initial", "max_columns", "max_coord",
    "cartesian_names", "earth_coord_names"};

const char * special[specialN] = {"multicopies"};

const char * obsolete[obsoleteN] = 
  { "oldstyle", "newstyle",  "newAniso", 
    "ambiguous", "normal_mode", "solvesigma",
    "optim_var_elimination", "sill",
    "matrix_inversion", "matrix_tolerance"
};
const char * ignore[ignoreN] ={"trend"};


const char **all[prefixN] = {general, gauss, krige, CE, direct, 
			     pnugget, sequ, spectral, pTBM, mpp,
			     hyper, extreme, br, distr, fit, 
			     empvario, gui, graphics, registers, internals, 
			     messages, coords, special, obsolete, ignore};

int allN[prefixN] = {generalN, gaussN, krigeN, CEN, directN,
		     pnuggetN,  sequN, spectralN, pTBMN, mppN,
		     hyperN, extremeN, brN, distrN, fitN, 
		     empvarioN, guiN, graphicsN, registersN, internalN, 
		     messagesN, coordsN, specialN, obsoleteN, ignoreN};



void setoptions(int i, int j, SEXP el, char name[LEN_OPTIONNAME], bool isList,
		  bool local) {  
  //  printf("setparameter %s %d %d local=%d\n", name, i, j, local);
   
  if (!local && parallel())
    ERR("'RFoptions' may not be set from a parallel process.")

  option_type *options = WhichOptionList(local);
  //bool isList = options == &OPTIONS;
  
  switch(i) {
  case 0: {// general
    general_options *gp;
    gp = &(options->general);
    switch(j) {
    case GENERAL_MODUS: {
      int old_mode = gp->mode;
      gp->mode = GetName(el, name, MODE_NAMES, nr_modes, normal);
#ifndef SCHLATHERS_MACHINE
      if (old_mode != gp->mode && options->messages.warn_modus_operandi) {
	  PRINTF("\n"); //verstehe wer will -- es gab hier eine valgrind warning
	 PRINTF("Note that behaviour of 'modus_operandi' has changed within 'RFfit' in version 3.1.0 of RandomFields. Roughly:\nwhat was called 'careless' is now called 'sloppy';\n");
PRINTF("what was called 'sloppy' is now called 'easygoing';\nwhat was called 'easygoing' is now called 'normal';\nwhat was called 'normal' is now called 'precise';\netc.\n");
	options->messages.warn_modus_operandi = false;
   }
#endif  
      SetDefaultModeValues(old_mode, gp->mode, local);
  }
       break;
    case GENERAL_STORING: {
      bool storing = LOGI;
      if  (length(el) > 1) {
	int len = length(el);
	for (int elnr=1; elnr < len; elnr++) {
	  int nr = Integer(el, (char*) "storing (register)", elnr);
	  if (nr>=0 && nr<=MODEL_MAX) {
	    model **key = KEY() + nr;
	      if (*key != NULL) COV_DELETE(key, NULL);
	  } else ERR("register number out of range");
	}
      } else if (gp->storing) {	  
	  // delete all keys
	if (local) {
	  for (int nr=0; nr<=MODEL_MAX; nr++) {
	    model **key = KEY() + nr;
	    if (*key != NULL) COV_DELETE(key, NULL);
	  }
	} else PIDKEY_DELETE();
      }
      gp->storing = storing;
      //printf("storing: get=%d set=%d\n", storing, gp->storing);
    }
      break;
   case 2: gp->every = POS0INT;      break;
    case 3: gp->gridtolerance = NUM; break;
    case 4: gp->pch = CHR;           break;
    case 5: 
      int n;
      n =INT;  
      if (n!=0 && n!=1 && n!=2 && n!=3)
	RFERROR("PracticalRange out of range. It should be TRUE or FALSE.");
       gp->naturalscaling = n;
      break;
    case 6: 
      //printf("case 6\n");
      SetDefaultOutputModeValues(LOGI ? output_sp : output_rf, local);
      break;
    case GENERAL_EXACTNESS: gp->exactness = USRLOG; break; 
    case 8: gp->duplicated_loc =
	GetName(el, name, DUPLICATEDLOC_NAMES, nDuplicatedloc); break; 
    case 9: gp->na_rm_lines = LOGI; break;
    case GENERAL_CLOSE: gp->vdim_close_together = LOGI;    
      if (gp->vdim_close_together) {
	gp->vdim_close_together = false;
 	RFERROR1("'%.50s' will likely not be programmed", general[GENERAL_CLOSE]);
	// Achtung! gausslikeli.cc waere stark betroffen!!
      }
      break;
    case 11: gp->expected_number_simu = POS0INT; break;
    case 12: gp->detailed_output = LOGI; break;
    case 13: gp->Ttriple = INT; break;
    case 14: gp->returncall = LOGI; break;
    case 15:
      // printf("case 15\n");
      SetDefaultOutputModeValues((output_modes) 
				 GetName(el, name, OUTPUTMODE_NAMES, 
					 nr_output_modes, gp->output), local);
      break;
    case GENERAL_REPORTCOORD:
      gp->reportcoord = GetName(el, name, REPORTCOORD_NAMES, 
				nr_reportcoord_modes, gp->reportcoord);
      break;      
    case 17: {      
      // gp->set = POSINT - 1;
      if (POSINT != 1) ERR("option 'set' currently disabled. Please contact maintainer if option is needed.");
      break;
    }
    case 18: gp->seed_incr = INT; break;
    case 19: gp->seed_sub_incr = INT; break;
    default: BUG;
    }}
    break;
  case 1: { // gauss
    gauss_options *gp;
    gp = &(options->gauss);
    switch(j) {
    case 0: gp->paired = LOGI; break;
    case 1: gp->stationary_only = USRLOG; break;
    case 2: gp->approx_zero = POS0NUM; break;
    case GAUSS_BEST_DIRECT: gp->direct_bestvariables = POS0INT;    break;
    case 4: gp->loggauss = LOGI;
      if (gp->loggauss) gp->boxcox[0] = RF_INF;
      break;
    case GAUSS_BOXCOX_OPTION: {
      int len = length(el);
      double boxcox[2 * MAXBOXCOXVDIM];      
      if (len < 1 || (len > 2 && len % 2 != 0))
       RFERROR1("'%.50s' not a scalar or vector/matrix of multiple of length 2",
	     gauss[GAUSS_BOXCOX_OPTION]);
      if (len > 2 * MAXBOXCOXVDIM) {
	RFERROR1("Box-Cox transformations can be applied only to the first %d multivariate dimensions",	MAXBOXCOXVDIM);
      }
      boxcox[1] = 0.0;
      for (int L=0; L<len; L++) boxcox[L] = Real(el, name, L);
      if (len == 1) len = 2;
      for (int k=0; k<len; k++) {
	if (R_FINITE(boxcox[k])) {
	  if (boxcox[k] < options->fit.BC_lambdaLB[k]) 
	    RFERROR6("%10g=%.50s[%d] < %.50s[%d]=%10g.", 
		     boxcox[k], gauss[GAUSS_BOXCOX_OPTION], k, fit[FIT_BC_LB],k,
		     options->fit.BC_lambdaLB[k]);
	  if (boxcox[k] > options->fit.BC_lambdaUB[k]) 
	    RFERROR6("%10g=%.50s[%d] > %.50s[%d]=%10g.", 
		     boxcox[k],gauss[GAUSS_BOXCOX_OPTION], k, fit[FIT_BC_UB], k,
		     options->fit.BC_lambdaUB[k]); 
	}
      }
      for (int k=0; k<len; k++) gp->boxcox[k] = boxcox[k];
      if (ISNA(gp->boxcox[0]) || gp->boxcox[0] != RF_INF) gp->loggauss = false;	
    }
      break;
    default: BUG;
    }}
    break;
  case 2: { // krige
    krige_options *kp;
    kp = &(options->krige);
    switch(j) { 
    case 0: kp->ret_variance = LOGI; break;
    case 1: kp->locmaxn = POS0INT; break;
    case KRIGE_SPLITN: {
      int  newval[3],
	len = length(el);
      if (len < 3) RFERROR1("'%.50s' must have 3 components", krige[KRIGE_SPLITN]);
      for (int ii=0; ii<len; ii++) {
	newval[ii] = Integer(el, name, ii); 
      }
      if (newval[0] > newval[1] || newval[1] > newval[2]) {
	RFERROR6("%.50s[1] <= %.50s[2] <= %.50s[3] not satisfied [ %d %d %d ]",
	     krige[KRIGE_SPLITN], krige[KRIGE_SPLITN], krige[KRIGE_SPLITN],
	     newval[0], newval[1], newval[2]
	     ); 
      } 
      for (int ii=0; ii<len; ii++) kp->locsplitn[ii] = newval[ii];
    }
      break;
    case 3: kp->locsplitfactor = POS0INT; break;
    case 4: kp->fillall = LOGI; break;
    default: BUG;
    }}
    break;
  case 3: // CE
    CE_set(el, j, name, &(options->ce), isList); 
    break;
  case 4: { //direct
    direct_options *dp;
    dp = &(options->direct);
    switch(j) {
    case DIRECT_MAXVAR_PARAM : {
      int mv = POS0INT;   
 
      if (mv <= options->gauss.direct_bestvariables) {
	RFERROR3("'%.50s' must be greater than '%.50s' = %d.\n", 
	     direct[DIRECT_MAXVAR_PARAM], gauss[GAUSS_BEST_DIRECT], 
	     options->gauss.direct_bestvariables);
      }
      //#define MAX_DIRECT_MAXVAR 30000
      if (mv > MAX_DIRECT_MAXVAR) {
	if (dp->maxvariables <= MAX_DIRECT_MAXVAR) {
	  WARN3("'%.50s' should better not exceed %d. The option 'max_chol' of package RandomFieldsUtils has also been set to %d.\n", 
		direct[DIRECT_MAXVAR_PARAM], MAX_DIRECT_MAXVAR, mv);
	}	
      }
      dp->maxvariables = mv;
      solve_options *sp;
      if (local) {
	KEY_type *KT = KEYT();
	if (KT == NULL) BUG;
	sp = &(KT->global_utils.solve);
      } else sp = &(OPTIONS_UTILS->solve);
      sp->max_chol= MAX(mv, DIRECT_ORIG_MAXVAR);
    }
     break;
    default: BUG;
    }}
    break;
  case 5:  {// pnugget, 
    nugget_options *np;
    np = &(options->nugget) ;
    switch(j) {
    case 0: np->tol = POS0NUM; break;
    default: BUG;
    }}
    break;
  case 6: {//sequ,
    sequ_options *sp;
    sp = &(options->sequ) ;
    switch(j) {
    case 0: sp->back = INT; if (sp->back < 1) sp->back=1;   break;
    case 1: sp->initial = INT; break;
    default: BUG;
    }}
    break;
  case 7: { // spectral,
    spectral_options *sp;
    sp = &(options->spectral) ;
    switch(j) {
    case 0: Integer(el, name, sp->lines, MAXTBMSPDIM); break;
    case 1: sp->grid = LOGI; break;
    case SPECTRAL_PROPFACTOR: sp->prop_factor = POS0NUM;
      if (sp->prop_factor <= 0.1) {
	sp->prop_factor=0.1;
	WARN1("'%.50s' less than 0.1. Set to 0.1.", spectral[SPECTRAL_PROPFACTOR]);
      }
      break;
    case 3: sp->sigma = NUM; break;
    default:  BUG;
    }}
    break;
  case 8: {// TBM
    tbm_options *tp;
    tp = &(options->tbm) ;
    switch(j) {
    case 0: tp->tbmdim = INT; break;
    case 1: tp->fulldim = POS0INT; break;
    case 2: Real(el, name, tp->center, MAXTBMSPDIM);  break;
    case 3: tp->points = POS0INT; break;
    case 4: Integer(el, name, tp->lines, MAXTBMDIM); break;
    case 5: 
      tp->linesimufactor = Real(el, name, 0);
      
      if (tp->linesimufactor < 0.0) {
	warning("Both 'linesimufactor' and 'linesimustep' must be non-negative.");
	tp->linesimufactor = 0.0;
      }
      if (tp->linesimufactor>0.0 && tp->linesimustep>0.0) tp->linesimustep=0.0;
      break;
    case 6: 
      tp->linesimustep = Real(el, name, 0);  
      if (tp->linesimustep < 0.0) {
	warning("Both 'linesimufactor' and 'linesimustep' must be non-negative.");
	tp->linesimustep = 0.0;
      }
      if (tp->linesimufactor>0.0 && tp->linesimustep>0.0) 
	tp->linesimufactor=0.0;
      break;
    case 7:
      tp->layers = UsrBool(el, name, 0);
      break;      
    case 8: 
      tp->grid = LOGI; break;
    default:  BUG;
    }}
    break;
  case 9: {//  mpp, 
    mpp_options *mp;
    mp = &(options->mpp);
    switch(j) {
    case 0: mp->n_estim_E = POS0INT; break;
    case 1: Real(el, name, mp->intensity, MAXMPPDIM); break;
      // case 2: mp->refradius_factor = POS0NUM; break;
    case 2: mp->about_zero = POS0NUM; break;
    case 3: mp->shape_power = NUM; break;
    case 4: {
      Integer(el, name, mp->scatter_max, MAXMPPDIM) ;
    }
      break;
    case 5: {
      Real(el, name, mp->scatter_step, MAXMPPDIM) ;
    }
      break;
    default: BUG;
   }}
    break;
  case 10: {//hyper, 
    hyper_options *hp;
    hp = &(options->hyper);
    switch(j) {
    case 0: hp->superpos = POS0INT;  break;
    case 1: hp->maxlines = POS0INT;  break;
    case 2: hp->mar_distr = INT; break;
    case 3: hp->mar_options = NUM; break;
    default:  BUG;
    }}
    break;
  case 11: {//		 extreme
    extremes_options *ep;
    ep = &(options->extreme);
    switch(j) {
    case 0: ep->standardmax = POS0NUM; break;
    case 1: ep->maxpoints = POS0INT; break;
    case 2: ep->GEV_xi = NUM; break;
    case 3: ep->density_ratio = POS0NUM; break;
    case 4: ep->check_every = POS0INT; break;
    case EXTREME_FLAT: ep->flathull = USRLOG; 
      //     if (ep->flathull != False) 
      // RFERROR1("currently only '%.50s=FALSE' allowed", extreme[EXTREME_FLAT]);
      // Programmierfehler in Huetchen.c
      break;
    case 6: ep->min_n_zhou = POSINT; break;
    case 7: ep->max_n_zhou = POSINT; break;
    case 8: ep->eps_zhou = POSNUM; break;
    case 9: ep->mcmc_zhou = POSINT; break;
    case 10: ep->min_shape_gumbel = NEG0NUM; break;
    case 11: ep->scatter_method =   
	(coord_sys_enum) GetName(el, name, POISSON_SCATTER_NAMES,
				 nPOISSON_SCATTER, POISSON_SCATTER_ANY);
      break; 
   default:  BUG;
    }}
    break;
  case 12 : { // br
    br_options *ep;
    ep = &(options->br);
    switch(j) {
    case 0: ep->BRmaxmem = POSINT; break;
    case 1: ep->BRmeshsize = POSNUM; break;
    case 2: ep->BRvertnumber = POSINT; break;
    case 3: ep->BRoptim = POS0INT; break;
    case 4: ep->BRoptimtol = POS0NUM; break;
    case 5: ep->variobound = NUM; break;
    case 6: ep->deltaAM = POSINT; break;
    default:  BUG;
    }}
    break;
  case 13 : {// distr
    distr_options *ep;
    ep = &(options->distr);
    switch(j) { 
    case 0: ep->safety=POSNUM; break;
    case 1: ep->minsteplen=POS0NUM; break;
    case 2: ep->maxsteps=POSINT; break;
    case 3: ep->parts=POSINT; break;
    case 4: ep->maxit=POSINT; break;
    case 5: ep->innermin=POSNUM; break;
    case 6: ep->outermax=POSNUM; break;
    case 7: ep->mcmc_n=POSNUM; break;
    case 8: ep->repetitions=POSNUM; break;
    default:  BUG;
    }}
    break;
  case 14: { // fit
    fit_options *ef;
    ef = &(options->fit);
    switch(j) {
    case 0: ef->bin_dist_factor = POS0NUM; break; //
    case 1: ef->upperbound_scale_factor = POS0NUM; break; //
    case 2: ef->lowerbound_scale_factor = POS0NUM; break; //
    case 3: ef->lowerbound_scale_LS_factor = POS0NUM; break; //
    case 4: ef->upperbound_var_factor = POS0NUM; break; //
    case 5: ef->lowerbound_var_factor = POS0NUM; break;//
      //    case 6: ef->lowerbound_sill = POS0NUM; break; 
    case 6: ef->scale_max_relative_factor = POS0NUM; break; //
    case 7: ef->minbounddistance = POS0NUM; break;//
    case 8: ef->minboundreldist = POS0NUM; break;// 
    case 9: ef->approximate_functioncalls = POS0INT; break; //
    case FIT_BC_LB: { 
	if (length(el) > 2 * MAXBOXCOXVDIM)
	  RFERROR1("Box-Cox transformations can be applied only to the first %d multivariate dimensions", MAXBOXCOXVDIM);
	Real(el, name, ef->BC_lambdaLB, 2 * MAXBOXCOXVDIM);
      break;
    }
    case FIT_BC_UB: {
      if (length(el) > 2 * MAXBOXCOXVDIM)
	RFERROR1("Box-Cox transformations can be applied only to the first %d multivariate dimensions", MAXBOXCOXVDIM);
      Real(el, name, ef->BC_lambdaUB, 2 * MAXBOXCOXVDIM);
      break;
    }
    case 12: ef->use_naturalscaling = LOGI; break;
    case 13: ef->onlyuser = LOGI; break;
    case 14: { // mle
      int ii=POS0INT; 
      if (ii==0) { ii = 1; warning("shortnamelength set to 1"); }
      if (ii >= LENMSG) {
	ii = LENMSG - 1;  
	WARN1("shortnamelength set to %d", ii); 
      }
      ef->lengthshortname=ii;
    }
    break;
    case 15: ef->split = INT; break;
    case 16: ef->scale_ratio = NUM; break;//
    case 17: ef->critical = INT; break;//
    case 18: ef->n_crit = POS0INT; break;///
    case FIT_MAXNEIGHBOUR: ef->locmaxn = POS0INT; break;//
    case FIT_CLIQUE: {
      int  newval[3],
	len = length(el);      
      if (len < 1 || len > 3) 
	RFERROR1("'%.50s' must have between 1 and 3 components", fit[FIT_CLIQUE]);
      for (int ii=0; ii<len; ii++) newval[ii] = Integer(el, name, ii); 
      if (len == 1) newval[1] = newval[2] = newval[0];
      else if (len == 2) {
	newval[2] = newval[1];
	newval[1] = (int) SQRT((double) newval[1] * newval[0]);
      }

      if (newval[0] > newval[1] || newval[1] > newval[2]) 
   	RFERROR3("%.50s[1] <= %.50s[2] <= %.50s[3] not satisfied",
	     fit[FIT_CLIQUE], fit[FIT_CLIQUE], fit[FIT_CLIQUE]
	     );      
      for (int ii=0; ii<3; ii++) ef->locsplitn[ii] = newval[ii];
      break;
    }
    case 21: ef->locsplitfactor = POS0INT; break;//
    case 22: ef->smalldataset = POS0INT; break;//
    case 23: ef->min_diag = NUM; break;//
    case 24: ef->reoptimise = LOGI; break;
    case 25: ef->suboptimiser =  ef->optimiser =
      GetName(el, name, OPTIMISER_NAMES, nOptimiser, 0);
      break;      
    case 26: // z.z. nur einer 
      ef->algorithm = GetName(el, name, NLOPTR_NAMES, nNLOPTR); //
      break;
    case 27: ef->likelihood =
	GetName(el, name, LIKELIHOOD_NAMES, nLikelihood); ; break; 
    case 28: ef->ratiotest_approx = LOGI; break;
    case 29: ef->split_refined = LOGI; break;
    case 30: ef->cross_refit = LOGI; break;
    case 31: ef->estimate_variance = USRLOG; break;
    case 32: ef->pgtol = POSNUM; break;//
    case 33: ef->pgtol_recall = POSNUM; break;//
    case 34: ef->factr = POSNUM; break;//
    case 35: ef->factr_recall = POSNUM; break;//
    case 36: ef->addNAlintrend = POS0NUM; break;
    case 37: {
      double m = NUM;
      if (FABS(m) <= 2.0) ef->emp_alpha = m;
      else RFERROR("'emp_method' not witin {RC_VARIOGRAM, RC_PSEUDO, RC_COVARIANCE}");
      break;
    }
    case 38: ef->suggesting_bounds = LOGI; break;
    case 39: ef->trace = INT; break;
    case 40: ef->suboptimiser =  
	GetName(el, name, OPTIMISER_NAMES, nOptimiser, 0); //
      break;
    case 41: ef->return_hessian = LOGI; break;
    case 42: ef->standardizedL = LOGI; break;
    default:  BUG;
      }}
  break;
  case 15: { // empvario
    empvario_options *ep;
    ep = &(options->empvario);
    switch(j) {
    case 0:
      ep->phi0=POS0NUM;
      if (ep->phi0 > TWOPI) ep->phi0 = mod(ep->phi0, TWOPI);
      break;
    case 1:
      ep->theta0=POS0NUM;
      if (ep->theta0 > TWOPI) ep->theta0 = mod( ep->theta0, TWOPI);
      break;    
    case 2: ep->tol=NUM; break;    
    case 3:
      ep->fft = LOGI;
      if (ep->fft) {
	ERR("fft is currently disabled"); // TO DO
	ep->fft = false;
      }
      break;
    case 4: ep->halveangles = LOGI; break;

    case 5: {
      int n = length(el);
      if (n > MAXBINS)
	RFERROR3("'%.50s' takes at most %d values. Got %d\n", name, MAXBINS, n);
      ep->nbins = n;
      if (n == 1) {
	double val = Real(el, name, 0);
	if (val != (int) val || val < 0)
	  RFERROR1("If '%.50s' is a single value, it must be a non-negative integer\n", name);
	ep->bins[0] = val;
      } else for (int u=0; u<n; u++) ep->bins[u] = Real(el, name, u);
    }
      break;
    case 6: if (length(el) == 0) ep->nphi = 0;
      else if (length(el) == 1) ep->nphi = POS0INT;
      else {
	ep->phi0=NUM;
	ep->nphi = Integer(el, name, 1);
	if (ep->nphi<0) {
	  ep->nphi=0; 
	  WARN1("'%.50s', which has been negative, is set 0.\n",name);
	}
      }
      break;//
    
    case 7: if (length(el) == 0) ep->ntheta = 0;
      else if (length(el) == 1) ep->ntheta = POS0INT;
      else {
	ep->theta0=NUM;
	ep->ntheta = Integer(el, name, 1);
	if (ep->ntheta<0) {
	  ep->ntheta=0; 
	  WARN1("'%.50s', which has been negative, is set 0.\n",name);
	}
      }
      break;//
    case 8: {
      double to = Real(el, name, 0),
	step = 1.0;
      if (length(el) > 1) Real(el, name, 1);      
      if (to <= 0.0) to = step = 0.0;
      else if (step > to || step <= 0.0) {
	WARN1("In '%.50s', step has been negative or larger than endpoint.\n",name);
	step = to;
      }
      ep->deltaT[0] = to;
      ep->deltaT[1] = step;
    }
      break;//
    default: BUG;
    }}
    break;
    case 16: { // gui
      gui_options *gp;
      gp = &(options->gui);
      switch(j) {
      case 0: gp->alwaysSimulate = LOGI; break;
      case 1: 
	gp->method = GetName(el, name, METHOD_NAMES, Forbidden + 1, Nothing);
	break;
      case GUI_SIZE: {
	int sizedummy[2];
	if (length(el) != 2) RFERROR1("length of '%.50s' must be 2", gui[GUI_SIZE]);
	Integer(el, name, sizedummy, 2);
	for (int ii=0; ii<2; ii++) {	
	  if (sizedummy[ii] <= 1) 
	    RFERROR("grid in RFgui must contain at least 2 points");
	}
	for (int ii=0; ii<2; ii++) {	 gp->size[ii] = sizedummy[ii]; }
      }
	break;
      default: BUG;
      }}
      break;
      case 17: { // graphics
	graphics_options *gp = &(options->graphics);
	switch(j) {
	case 0 : gp->close_screen = LOGI; break;
	case 1 : gp->PL = INT; break;
	case 2 : gp->height = NUM; break;
	case GRAPHICS_UPTO : {
	  int uptodummy[2];
	  if (length(el) != 2)
	    RFERROR1("length of '%.50s' must be 2", graphics[GRAPHICS_UPTO]);
	  Integer(el, name, uptodummy, 2);
	  for (int ii=0; ii<2; ii++) {
	    if (uptodummy[ii] <= 0)  RFERROR("increase_upto must be positive");
	  } 
	  for (int ii=0; ii<2; ii++) { gp->increase_upto[ii] = uptodummy[ii]; }
	}
	  break;
	case 4 : gp->always_open = USRLOG;
	  break;
	case 5 :
	  if (!isList) {
	    char old[100];
	    strcopyN(old, gp->filename, 100);
	    STR(gp->filename, 100);
	    if (!gp->onefile && STRCMP(gp->filename, old) !=0) gp->number = 0;
	  }
	  break;
	case 6 :  if (!isList) {
	    bool onefile = gp->onefile;
	    gp->onefile = LOGI;
	    if (!gp->onefile && onefile) gp->number = 0;
	  } break;
	case 7 :  if (!isList) { 
	    gp->number = INT; 
	  }
	  break;
	case 8 : gp->resolution = POSNUM; break;
	case 9 : gp->split_screen = LOGI; break;
	case 10 : gp->width = NUM; break;
	case 11 : gp->always_close = USRLOG; break;
	case 12 : gp->grDefault = LOGI; break;
	case 13 : gp->xlim = POSNUM; break;
	case 14 : gp->maxchar = POSINT; break;
	case 15 : Integer(el, name, gp->npoints, 2); break;
	default: BUG;      
	}}
	break;
	case 18 : {
	  registers_options *rp = &(options->registers);
	  switch(j) {
	  case 0: { // simu
	    int keynr = INT;
	    if ((keynr<0) || (keynr>MODEL_MAX))
	      RFERROR("register number out of range");
	    rp->keynr=keynr; }
      break;
    case 1: { //  predict
      int predict = INT;
      if ((predict<0) || (predict>MODEL_MAX))
	RFERROR("register number out of range");
      rp->predict=predict; }
      break;
    case 2: { //  likelihood
      int likelihood = INT;
      if ((likelihood<0) || (likelihood>MODEL_MAX))
	RFERROR("register number out of range");
      rp->likelihood=likelihood; }
      break;
    default: BUG;
    }}
    break;

  case 19: {
    internal_options *wp = &(options->internal);
    // ACHTUNG internal wird nicht pauschal zurueckgesetzt !
    switch(j) {
      case INTERNALS_DO_TESTS: wp->do_tests = LOGI;       break;
      case INTERNALS_EX_RED: wp->examples_reduced= POS0INT;  
	if (wp->examples_reduced > 0 && 
	    wp->examples_reduced < MAX_LEN_EXAMPLES)
	  wp->examples_reduced = MAX_LEN_EXAMPLES;
	break;
    default: BUG; 
    }
  }
    break;

  case 20: {
    messages_options *wp = &(options->messages);
    // ACHTUNG messages wird nicht pauschal zurueckgesetzt !
    if (!isList) {
      switch(j) {
      case 0: wp->warn_oldstyle = LOGI;       break;
      case 1: wp->help_newstyle = LOGI;       break;
      case MESSAGES_NEWANISO: wp->warn_Aniso = LOGI;       break;
      case 3: wp->note_ambiguous = LOGI;       break;
      case 4: wp->help_normal_mode = LOGI;       break;
      case 5: wp->warn_mode = LOGI;       break;
      case 6: wp->warn_scale = LOGI;       break;
      case 7: wp->note_coordinates = POS0INT;	break;
      case MESSAGES_ONGRID: wp->warn_on_grid = LOGI;       break;
      case 9: wp->note_no_fit = LOGI;       break;
      case 10: wp->note_aspect_ratio = LOGI;       break;
      case MESSAGES_COORD_CHANGE: wp->warn_coord_change = LOGI;       break;
      case 12: wp->help_color_palette = LOGI;       break;
      case MESSAGES_ZENIT: wp->warn_zenit = LOGI;       break;
      case 14: wp->warn_constant = LOGI;       break;
      case 15: wp->warn_negvar = LOGI;       break;
      case 16: wp->help_onlyvar = LOGI;       break;
      case 17: wp->warn_mathdef = USRLOG; break;
      case 18: wp->warn_seed = POS0INT; break;
      case 19: wp->warn_modus_operandi = LOGI; break;
      case 20: wp->warn_singlevariab = LOGI; break;
      case 21: wp->help_mle = LOGI; break;
      case 22: wp->note_detection = POS0INT; break;
      case MESSAGES_RAW: wp->warn_raw_covariates = LOGI; break;
      case 24: wp->help_addNA = LOGI; break;
      case 25: wp->help_help = LOGI; break;
      case 26: wp->warn_ambiguous = LOGI;       break;
      case 27: wp->vec_len = POSINT;       break;
      case 28: wp->warn_examples_reduced = LOGI; break;
   default: BUG; 
      }
    } else {
      switch(j) {
      case MESSAGES_ONGRID :  wp->warn_on_grid = LOGI; break;
      case MESSAGES_COORD_CHANGE: wp->warn_coord_change = LOGI;       break;
      case MESSAGES_ZENIT: wp->warn_zenit = LOGI;       break;
      case MESSAGES_RAW: wp->warn_raw_covariates = LOGI; break; 	
      default : {} // none
      }
    }
  }
    break;


  case 21: {
    coords_options *cp = &(options->coords);
    switch(j) {
    case COORDS_XYZNOTATION: cp->xyz_notation = USRLOG; break;
    case 1: {
      coord_sys_enum coord =
	(coord_sys_enum) GetName(el, name, COORD_SYS_NAMES, nr_coord_sys,
				 coord_auto);
      if (coord == coord_auto || coord == earth || coord == sphere || 
	  coord == cartesian)
	cp->coord_system = coord;
      else RFERROR2("Cannot take '%.50s' as a value for the initial '%.50s'", 
		CHAR(STRING_ELT(el, 0)), coords[j]);
      if ((coord == earth && cp->anglemode != degree) ||
	  (coord != earth && cp->anglemode == degree)
	  ) {
	cp->anglemode = coord == earth ? degree : radians;
	if (PL > 0 && !isList) {
	  PRINTF("Angle mode switches to '%s'.\n", ANGLE_NAMES[cp->anglemode]);
	}
      }
    } 
     break; 
    case 2: getUnits(el, name, cp->newunits, NULL);  break;
    case 3: getUnits(el, name, cp->curunits, isList ? NULL : cp->newunits);
      break;
    case 4: getUnits(el, name, cp->varunits, NULL);  break;
    case DATA_IDX: {
      // either exct column number must be given
      //                      or a set of potential variable names
      Integer2(el, name, cp->data_idx);
      if (cp->data_idx[1] != NA_INTEGER) { // snd = NA : mean all after first
	//	int n = cp->data_idx[1] - cp->data_idx[0] + 1;
	//       	if (n > MAXDATANAMES) 
	  //RFERROR1("maximum number named variables is %d", MAXDATANAMES);
	cp->n_data_names = 0;
      }}
      break;
    case DATA_NAMES: {
      int len = length(el);
      if (len > MAXDATANAMES) {
	WARN3("vector '%.20s' is too long (current=%d > max=%d)",// along
	      coords[DATA_NAMES], len, MAXDATANAMES);
        len = MAXDATANAMES;
     }
      cp->n_data_names = len;
      if (len > 0) String(el, name, cp->data_names, len);
      //printf("set n=%d\n", cp->n_data_names);
    }
      break; 
    case COORDS_XIDX: {
      Integer2(el, name, cp->x_idx);
      if (cp->x_idx[1] != NA_INTEGER) {// snd = NA : mean all after first
	int n =  cp->x_idx[1] - cp->x_idx[0] + 1;
	if (n > MAXCOORDNAMES) {
	  //	  WARN1("maximum number named variables is %d", MAXCOORDNAMES);
	  //n = MAXCOORDNAMES;
	}
	cp->n_x_names = 0;
      }}
      break;
    case COORDS_XNAMES:{
      int len = length(el);
      if (len > MAXCOORDNAMES) {
	RFERROR1("vector '%.20s' is too long", coords[COORDS_XNAMES]); // along
 	len = MAXCOORDNAMES;
      }
     cp->n_x_names = len;
      if (len > 0) String(el, name, cp->x_names, len);
    }
      break;
    case 9: 
      cp->new_coord_system =
	(coord_sys_enum) GetName(el, name, COORD_SYS_NAMES, nr_coord_sys,
				 coord_keep);
      if (cp->new_coord_system == coord_auto) cp->new_coord_system = coord_keep;
      break; 

    case ZENIT: Real(el, name, cp->zenit, 2);
      break;  
    case 11: cp->polar_coord = LOGI; break;
    case 12: cp->anglemode =
	(angle_modes) GetName(el, name, ANGLE_NAMES, last_angle_mode + 1, -1);
     break; 
    case 13: cp->allow_earth2cart = LOGI; break;
    case 14: STR(cp->data_col_initial, MAXCHAR-1);
      if (STRLEN(cp->data_col_initial) > 0 &&
	  !STRCMP(cp->data_col_initial,cp->coord_initial)) {
	ERR("'data_col_initial' and 'coord_initia' may not be the same");
	STRCPY(cp->data_col_initial, "");
      }
      break;
    case 15: STR(cp->coord_initial, MAXCHAR-1);
      if (STRLEN(cp->coord_initial)>0 &&
	  !STRCMP(cp->data_col_initial,cp->coord_initial)) {
	ERR("'data_col_initial' and 'coord_initia' may not be the same.");
	STRCPY(cp->coord_initial, "");
      }
      break;
    case 16: cp->max_col = POSINT; break;
    case 17: cp->max_coord = POSINT; break;
    case 18:
      if (length(el) != 4)
	ERR("vector of cartesian names must have 4 elements.");
      String(el, name, cp->cartesian_names, 4);
      break;
    case 19:
      if (length(el) != 4)
	ERR("vector of earth coordinates names must have 4 elements.");
      String(el, name, cp->earthcoord_names, 4);
      break;     
   default: BUG;
    }}
    break;

  case 22: {
    special_options *sp = &(options->special);
    switch(j) {
    case 0: sp->multcopies = POSINT;
	break;      
    default: BUG;
    }}
    break;


  case 23: { // obsolete
    messages_options *wp = &(options->messages);
    switch(j) {
    case 0: wp->warn_oldstyle = LOGI;       break;
    case 1: wp->help_newstyle = LOGI;       break;
    case 2: wp->warn_Aniso = LOGI;       break;
    case 3: wp->note_ambiguous = LOGI;       break;
    case 4: wp->help_normal_mode = LOGI;       break;
    case 8: RFERROR("'matrix_inversion' has been changed to 'matrix_methods'" );
      break;
    case 9: RFERROR("'matrix_tolerance' has been changed to 'svd_tol'" );
      break;

    default:
      RFERROR1("RFoption '%.50s' has been removed.", obsolete[j]);
    }}
    break;

  case 24: { // ignore
    switch(j) {
    case 0 : // printf("trend type = %d\n", TYPEOF(el));
      break;
    default: BUG;
    }}
    break;

  default: BUG;
  }
  // printf("end setparameter\n");
}




#define AddScalarLogInt(X)						\
  if ((X)==0 || (X)==1) {ADD(ScalarLogical(X));} else {ADD(ScalarInteger(X));}

void getoptions(SEXP sublist, int i, bool local) {
  //  printf("get %d local=%d\n", i, local);
    int k=0;
  char x[2]=" ";
  //#define ADD(ELT) {printf(#ELT"\n");SET_VECTOR_ELT(sublist, k++, ELT);}
  option_type *options = WhichOptionList(local);
  switch(i) {
  case 0 : { 
     general_options *p = &(options->general);
    ADD(ScalarString(mkChar(MODE_NAMES[p->mode])));
    ADD(ScalarLogical(p->storing));
    ADD(ScalarInteger(p->every));    
    ADD(ScalarReal(p->gridtolerance));
    ADDCHAR(p->pch);
    AddScalarLogInt(p->naturalscaling); 
    ADD(ScalarLogical(p->sp_conform));
    ADD(ExtendedBooleanUsr(p->exactness));    
    ADD(ScalarString(mkChar(DUPLICATEDLOC_NAMES[p->duplicated_loc])));
  
    ADD(ScalarLogical(p->na_rm_lines));   
    ADD(ScalarLogical(p->vdim_close_together));
    ADD(ScalarInteger(p->expected_number_simu));    
    ADD(ScalarLogical(p->detailed_output));   
    ADD(ScalarLogical(p->Ttriple == NA_INTEGER ? NA_LOGICAL
		      : p->Ttriple != 0));
    ADD(ScalarLogical(p->returncall));
    ADD(ScalarString(mkChar(OUTPUTMODE_NAMES[p->output])));
    ADD(ScalarString(mkChar(REPORTCOORD_NAMES[p->reportcoord])));
    ADD(ScalarInteger(p->set + 1));   
    ADD(ScalarInteger(p->seed_incr));   
    ADD(ScalarInteger(p->seed_sub_incr));   
  }
  break;
  
  case 1 : {
    gauss_options *p = &(options->gauss);
    // nachfolgend sollte immer >= 0 sein
    ADD(ScalarLogical(p->paired));   
    ADD(ExtendedBooleanUsr(p->stationary_only));
    ADD(ScalarReal(p->approx_zero));    
    ADD(ScalarInteger(p->direct_bestvariables));    
    ADD(ScalarLogical(p->loggauss));   
    SET_VECTOR_ELT(sublist, k++, Num(p->boxcox, 2 * MAXBOXCOXVDIM)); 
  }
   break;

  case 2 : {
    krige_options *p = &(options->krige);
    ADD(ScalarLogical(p->ret_variance));   
    ADD(ScalarInteger(p->locmaxn));
    SET_VECTOR_ELT(sublist, k++, Int(p->locsplitn, 3));
    ADD(ScalarInteger(p->locsplitfactor));
    ADD(ScalarLogical(p->fillall));   
  }
   break;
   
  case 3 : {
    ce_options *p = &(options->ce);
    ADD(ScalarLogical(p->force)); 
    SET_VECTOR_ELT(sublist, k++, Num(p->mmin, MAXCEDIM)); 
    ADD(ScalarInteger(p->strategy)); 
    ADD(ScalarReal(p->maxGB)); 
    ADD(ScalarReal(p->maxmem)); 
    ADD(ScalarReal(p->tol_im)); 
    ADD(ScalarReal(p->tol_re));	      
    ADD(ScalarInteger(p->trials));    
    ADD(ScalarLogical(p->useprimes)); 
    ADD(ScalarLogical(p->dependent)); 
    ADD(ScalarReal(p->approx_grid_step)); 
    ADD(ScalarInteger(p->maxgridsize));    
  } 
   break;
   
  case 4: {
    direct_options *p = &(options->direct);
    //ADD(ScalarInteger(p->inversionmethod));    
    //ADD(ScalarReal(p->svdtolerance));     
    ADD(ScalarInteger(p->maxvariables));    
  }
    break;

  case 5:  {
    nugget_options *p = &(options->nugget);
    ADD(ScalarReal(p->tol));
    // ADD(ScalarLogical(p->meth));
  }
    break;
    
  case 6 : {
    sequ_options *p = &(options->sequ);
    ADD(ScalarInteger(p->back));    
    ADD(ScalarInteger(p->initial));    
  }
   break;
   
  case 7 :; {
    spectral_options *p = &(options->spectral);
    SET_VECTOR_ELT(sublist, k++, Int(p->lines, MAXTBMSPDIM));
    ADD(ScalarLogical(p->grid));
    ADD(ScalarReal(p->prop_factor));
    ADD(ScalarReal(p->sigma));
  }
   break;

  case 8: {
    tbm_options *p = &(options->tbm);
    // nachfolgend sollte immer >= 0 sein
    ADD(ScalarInteger(p->tbmdim));
    ADD(ScalarInteger(p->fulldim));
    SET_VECTOR_ELT(sublist, k++, Num(p->center, MAXTBMSPDIM));
    ADD(ScalarInteger(p->points));     
    // ADD(p->method>=0 ? ScalarString(mkChar(METHOD_NAMES[p->method])) : 
    //	R_NilValue);
     SET_VECTOR_ELT(sublist, k++, Int(p->lines, MAXTBMDIM));
    ADD(ScalarReal(p->linesimufactor));
    ADD(ScalarReal(p->linesimustep));
    ADD(ExtendedBooleanUsr(p->layers));
    ADD(ScalarLogical(p->grid));
  }
   break;


  case 9: {
    mpp_options *p = &(options->mpp);
     ADD(ScalarInteger(p->n_estim_E));
    SET_VECTOR_ELT(sublist, k++, Num(p->intensity, MAXMPPDIM));
    //ADD(ScalarReal(p->refradius_factor));
    ADD(ScalarReal(p->about_zero));
    ADD(ScalarReal(p->shape_power));
    SET_VECTOR_ELT(sublist, k++, Num(p->scatter_step, MAXMPPDIM)); 
    SET_VECTOR_ELT(sublist, k++, Int(p->scatter_max, MAXMPPDIM)); 
     //    SET_VECTOR_ELT(sublist, k++, Num(p->plus, MAXMPPDIM ,MAXMPPDIM));
    //    ADD(ScalarReal(p->approxzero));
    //   ADD(ScalarReal(p->samplingdist));
    //  ADD(ScalarReal(p->samplingr));
     //  ADD(ScalarReal(p->p));
  }
   break;

  case 10: {
    hyper_options *p = &(options->hyper);
    ADD(ScalarInteger(p->superpos));    
    ADD(ScalarInteger(p->maxlines));    
    ADD(ScalarInteger(p->mar_distr));
    ADD(ScalarReal(p->mar_options));    
  }
   break;

  case 11 : {
    extremes_options *p = &(options->extreme);
    ADD(ScalarReal(p->standardmax));
    ADD(ScalarInteger(p->maxpoints));           
    ADD(ScalarReal(p->GEV_xi));
    ADD(ScalarReal(p->density_ratio));
    ADD(ScalarInteger(p->check_every));
    ADD(ExtendedBooleanUsr(p->flathull));
    ADD(ScalarInteger(p->min_n_zhou));
    ADD(ScalarInteger(p->max_n_zhou));
    ADD(ScalarReal(p->eps_zhou));
    ADD(ScalarInteger(p->mcmc_zhou));
    ADD(ScalarReal(p->min_shape_gumbel));
    ADD(ScalarString(mkChar(POISSON_SCATTER_NAMES[p->scatter_method])));
 
  }
   break;

  case 12: {
    br_options *p = &(options->br);
    ADD(ScalarInteger(p->BRmaxmem)); 
    ADD(ScalarReal(p->BRmeshsize));
    ADD(ScalarInteger(p->BRvertnumber));
    ADD(ScalarInteger(p->BRoptim));
    ADD(ScalarReal(p->BRoptimtol));
    ADD(ScalarReal(p->variobound));
    ADD(ScalarInteger(p->deltaAM));
  }
   break;

  case 13 : {
    distr_options *p = &(options->distr);
    ADD(ScalarReal(p->safety));
    ADD(ScalarReal(p->minsteplen));
    ADD(ScalarInteger(p->maxsteps));
    ADD(ScalarInteger(p->parts));
    ADD(ScalarInteger(p->maxit));
    ADD(ScalarReal(p->innermin));
    ADD(ScalarReal(p->outermax));
    ADD(ScalarInteger(p->mcmc_n));
    ADD(ScalarInteger(p->repetitions));
  }
   break;
   
  case 14 : {
    fit_options *p = &(options->fit);
    ADD(ScalarReal(p->bin_dist_factor));
    ADD(ScalarReal(p->upperbound_scale_factor)); 
    ADD(ScalarReal(p->lowerbound_scale_factor)); 
    ADD(ScalarReal(p->lowerbound_scale_LS_factor)); 
    ADD(ScalarReal(p->upperbound_var_factor)); 
    ADD(ScalarReal(p->lowerbound_var_factor));
    ADD(ScalarReal(p->scale_max_relative_factor)); 
    ADD(ScalarReal(p->minbounddistance));
    ADD(ScalarReal(p->minboundreldist));  
    ADD(ScalarInteger(p->approximate_functioncalls)); 
    SET_VECTOR_ELT(sublist, k++, Num(p->BC_lambdaLB, 2 * MAXBOXCOXVDIM));
    SET_VECTOR_ELT(sublist, k++, Num(p->BC_lambdaUB, 2 * MAXBOXCOXVDIM));
    ADD(ScalarLogical(p->use_naturalscaling));
    ADD(ScalarLogical(p->onlyuser));
    ADD(ScalarInteger(p->lengthshortname));
    ADD(ScalarInteger(p->split));
    ADD(ScalarReal(p->scale_ratio));
    ADD(ScalarInteger(p->critical));
    ADD(ScalarInteger(p->n_crit));
    ADD(ScalarInteger(p->locmaxn));
    SET_VECTOR_ELT(sublist, k++, Int(p->locsplitn, 3));
    ADD(ScalarInteger(p->locsplitfactor));
    ADD(ScalarInteger(p->smalldataset));
    ADD(ScalarReal(p->min_diag));
    ADD(ScalarLogical(p->reoptimise));
    ADD(p->optimiser>=0 ? ScalarString(mkChar(OPTIMISER_NAMES[p->optimiser])) 
	: R_NilValue);
    ADD(//p->algorithm == UNSET ? R_NilValue :
	ScalarString(mkChar(//p->optimiser == 3 ?
			    NLOPTR_NAMES[p->algorithm]
			    //: ""
			    )
		     ));
    ADD(ScalarString(mkChar(LIKELIHOOD_NAMES[p->likelihood])));
    ADD(ScalarLogical(p->ratiotest_approx));
    ADD(ScalarLogical(p->split_refined));
    ADD(ScalarLogical(p->cross_refit));
    ADD(ExtendedBooleanUsr(p->estimate_variance));
    ADD(ScalarReal(p->pgtol)); 
    ADD(ScalarReal(p->pgtol_recall)); 
    ADD(ScalarReal(p->factr)); 
    ADD(ScalarReal(p->factr_recall)); 
    ADD(ScalarInteger(p->addNAlintrend));
    ADD(ScalarReal(p->emp_alpha));
    ADD(ScalarLogical(p->suggesting_bounds));
    ADD(ScalarInteger(p->trace));
    ADD(p->suboptimiser>=0
	? ScalarString(mkChar(OPTIMISER_NAMES[p->suboptimiser])) 
	: R_NilValue);
    ADD(ScalarLogical(p->return_hessian));
    ADD(ScalarLogical(p->standardizedL));
   }  
   break;
   
  case 15: {
    empvario_options *p = &(options->empvario);   
    ADD(ScalarReal(p->phi0));
    ADD(ScalarReal(p->theta0));
    ADD(ScalarReal(p->tol));
    ADD(ScalarLogical(p->fft));
    ADD(ScalarLogical(p->halveangles));

    if (p->nbins == 0) ADD(R_NilValue);
    else if (p->nbins == 1) ADD(ScalarInteger(p->bins[0]));
    else SET_VECTOR_ELT(sublist, k++, Num(p->bins, p->nbins));

    ADD(ScalarInteger(p->nphi));
    ADD(ScalarInteger(p->ntheta));
    SET_VECTOR_ELT(sublist, k++, Num(p->deltaT, 2));
   }
   break;

  case 16: {
    gui_options *p = &(options->gui);   
    ADD(ScalarLogical(p->alwaysSimulate));
    ADD(p->method>=0 ? ScalarString(mkChar(METHOD_NAMES[p->method])) 
	: R_NilValue);
    SET_VECTOR_ELT(sublist, k++, Int(p->size, 2));
  }
   break;

  case 17 : {
    graphics_options *p = &(options->graphics);   
    ADD(ScalarLogical(p->close_screen));
    ADD(ScalarInteger(p->PL));
    ADD(ScalarReal(p->height));
    SET_VECTOR_ELT(sublist, k++, Int(p->increase_upto, 2));
    ADD(ExtendedBooleanUsr(p->always_open));
    ADD(ScalarString(mkChar(p->filename)));
    ADD(ScalarLogical(p->onefile));
    ADD(ScalarInteger(p->number));
    ADD(ScalarReal(p->resolution));
    ADD(ScalarLogical(p->split_screen));
    ADD(ScalarReal(p->width));
    ADD(ExtendedBooleanUsr(p->always_close));
    ADD(ScalarLogical(p->grDefault));
    ADD(ScalarReal(p->xlim));
    ADD(ScalarInteger(p->maxchar));
    SET_VECTOR_ELT(sublist, k++, Int(p->npoints, 2));
  }
   break;

  case 18: {
    registers_options *p = &(options->registers);
    ADD(ScalarInteger(p->keynr));    
    ADD(ScalarInteger(p->predict));    
    ADD(ScalarInteger(p->likelihood));
  }
   break;
  
  case 19 : {
    internal_options *p = &(options->internal);
    ADD(ScalarLogical(p->do_tests));
    ADD(ScalarInteger(p->examples_reduced));
  }
   break;

  case 20 : {
    messages_options *p = &(options->messages);
    ADD(ScalarLogical(p->warn_oldstyle));
    ADD(ScalarLogical(p->help_newstyle));
    ADD(ScalarLogical(p->warn_Aniso));
    AddScalarLogInt(p->note_ambiguous);
    ADD(ScalarLogical(p->help_normal_mode));    
    ADD(ScalarLogical(p->warn_mode));
    ADD(ScalarLogical(p->warn_scale));
    AddScalarLogInt(p->note_coordinates);
    ADD(ScalarLogical(p->warn_on_grid));    
    ADD(ScalarLogical(p->note_no_fit));
    ADD(ScalarLogical(p->note_aspect_ratio));
    ADD(ScalarLogical(p->warn_coord_change));
    ADD(ScalarLogical(p->help_color_palette));
    ADD(ScalarLogical(p->warn_zenit));
    
    ADD(ScalarLogical(p->warn_constant));
    ADD(ScalarLogical(p->warn_negvar));
    ADD(ScalarLogical(p->help_onlyvar));
    ADD(ExtendedBooleanUsr(p->warn_mathdef));
    
    ADD(ScalarInteger(p->warn_seed));    
    ADD(ScalarLogical(p->warn_modus_operandi));
    
    ADD(ScalarLogical(p->warn_singlevariab));
    ADD(ScalarLogical(p->help_mle));
    AddScalarLogInt(p->note_detection);
    ADD(ScalarLogical(p->warn_raw_covariates));
    ADD(ScalarLogical(p->help_addNA));
    ADD(ScalarLogical(p->help_help));
    AddScalarLogInt(p->warn_ambiguous);
    AddScalarLogInt(p->vec_len);
    ADD(ScalarLogical(p->warn_examples_reduced));
  }
   break;


   
  case 21 : {
    coords_options *p = &(options->coords);
    ADD(ExtendedBooleanUsr(p->xyz_notation));    
    ADD(ScalarString(mkChar(COORD_SYS_NAMES[p->coord_system])));
    ADD(UNITS(p->newunits));
    ADD(UNITS(p->curunits));
    ADD(UNITS(p->varunits)); // 4
    int idx_default[2] = {NA_INTEGER, NA_INTEGER};
    if (p->n_data_names == 0) {
      SET_VECTOR_ELT(sublist, k++, Int(p->data_idx, 2));
      SET_VECTOR_ELT(sublist, k++, String(NULL, 0));
    } else {
      assert(p->n_data_names < MAXDATANAMES);
      //printf("n_data %d %s %s\n", p->n_data_names, p->data_names[0], p->data_names[1]);
      SET_VECTOR_ELT(sublist, k++, Int(idx_default, 2));
      SET_VECTOR_ELT(sublist, k++, String(p->data_names, p->n_data_names));
    }
    if (p->n_x_names == 0) { // 7
      SET_VECTOR_ELT(sublist, k++, Int(p->x_idx, 2));
      SET_VECTOR_ELT(sublist, k++, String(NULL, 0));
    } else {
      assert(p->n_x_names < MAXDATANAMES);
	SET_VECTOR_ELT(sublist, k++, Int(idx_default, 2));
      SET_VECTOR_ELT(sublist, k++, String(p->x_names, p->n_x_names));
    }
    ADD(ScalarString(mkChar(COORD_SYS_NAMES[p->new_coord_system]))); //9
    SET_VECTOR_ELT(sublist, k++, Num(p->zenit, 2));     
    ADD(ScalarLogical(p->polar_coord));
    ADD(ScalarString(mkChar(ANGLE_NAMES[p->anglemode])));
    ADD(ScalarLogical(p->allow_earth2cart));
    ADD(ScalarString(mkChar(p->data_col_initial)));
    ADD(ScalarString(mkChar(p->coord_initial)));
    ADD(ScalarInteger(p->max_col));
    ADD(ScalarInteger(p->max_coord));    
    SET_VECTOR_ELT(sublist, k++, String(p->cartesian_names, 4));
    SET_VECTOR_ELT(sublist, k++, String(p->earthcoord_names, 4));
  }
   break;

  case 22 : {
    special_options *p = &(options->special);
    ADD(ScalarInteger(p->multcopies));    
  }
   break;

   case 23: {
     // obsolete arguments
   }
     break;
     
    case 24: {
     // ignored arguments: e.g. trend
   }
     break;
     
   
   default :
     //printf("i=%d\n", i);
     BUG;
  }
 

}

   
