/*
 Authors 
 Martin Schlather, schlather@math.uni-mannheim.de

 Definition of auxiliary correlation functions 

 Copyright (C) 2017 -- 2017 Martin Schlather

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  
*/


//#include <Rmath.h>
//#include <stdio.h> 
//#include <R_ext/Lapack.h>
//
#include "questions.h"
#include "operator.h"
#include "Processes.h"
#include "startGetNset.h"
#include "variogramAndCo.h"
#include "QMath.h"
//#include "shape.h"



bool istop(model *cov) {
  return cov->calling == NULL || !isnowShape(cov->calling);
}

bool CanHaveBothTrendAndCov(model *cov) {
  if (!PREV_INITIALISED) return true;
  bool plus = isPlus(cov),
    top = istop(cov),
    trend = equalsnowTrend(cov);
  Types covtype = PREVTYPE(0);
  //printf("%d %d %d Ecal=%d def=%d %d %s\n", plus, top, trend, hasAnyEvaluationFrame(cov), isNegDef(covtype), isProcess(covtype), TYPE_NAMES[covtype]);
  return plus && PisNULL(PLUS_TREND) && !trend && top &&
    hasAnyEvaluationFrame(cov) && (isNegDef(covtype) || isProcess(covtype));
}



int checkplusmal(model *cov) {
  ONCE_NEWSTOMODEL;
  model *sub;
  int  err, 
    vdim[2] = {1, 1},
    last = OWNLASTSYSTEM,
    possibilities = 1 + (int) CanHaveBothTrendAndCov(cov);
  bool plus = isPlus(cov),
    fullXdim = hasLikelihoodFrame(cov),
    *conform = cov->Splus == NULL ? NULL : cov->Splus->conform;;
  Types covtype = OWNTYPE(0),
    frame = fullXdim ? EvaluationType : cov->frame; // see also below exception:
  // LikelihoodType is passed downwards if sub is plus!


  //if (PREVISO(0) == SYMMETRIC) APMI(cov);
  
  /*
  domain_type covdom = trend ? X ONLY : OWNDOM(0);
  int trendiso = U pgradeToCoordinateSystem(OWNISO(0));
  if (trendiso == ISO_MISMATCH) trendiso = OWNISO(0);
  assert(trendiso != ISO_MISMATCH);
  int coviso = trend ? trendiso : OWNISO(0);
  */

  //  printf("top = %d %d %d shape=%d %s\n", top, cov->calling == NULL, cov->calling != NULL && !isnowShape(cov->calling), cov->calling != NULL && isnowShape(cov->calling), cov->calling == NULL ? "Niente" : NAME(cov->calling));



  //  if (OWNDOM(0) == XONLY && OWNISO(0) == EARTH_COORD && OWNTYPE(0) == NegDefType && false) { APMI0(cov);}
  // PMI0(cov);

  cov->matrix_indep_of_x = true;
  //  printf("checking plus A\n");
  for (int i=0; i<cov->nsub; i++) { 
    Types type = covtype;
    sub = cov->sub[i];
    if (sub == NULL) 
      SERR("+ or *: named submodels are not given in a sequence!");

    if (plus) {
      //  if (top && equalsnowMathDef(sub) && isNegDef(type)) // 16.1.21
      // wird nie erfuellt, sowie undefiniert da qualsnowMa erst nach
      //
    } else {
      if (equalsVariogram(type)) type=PosDefType; // mult: no multiplication
    }
  
    err = CERRORTYPECONSISTENCY;


    //    printf("+ %s %d\n", NAME(sub), possibilities);
    
    for (int j=0; j<possibilities; j++) {// nur trend als abweichender typus erlaubt
      //      printf("+ %s %d j=%d\n", NAME(sub), possibilities, j); // 2 BUG;
      //   APMI0(cov);
          //
      COPYALLSYSTEMS(PREVSYSOF(sub), OWN, false);
      for (int s=0; s<=last; s++) {	
	set_type(PREVSYSOF(sub), s, type);
	if (j != 0) set_type(PREVSYSOF(sub), s, TrendType); // iff j == 1
	//	printf("plus %s %d %s j=%d (%d) %d\n", NAME(cov), i, NAME(sub), j, possibilities,  equalsTrend(type));
	if (equalsTrend(type)) {
	  //if (!equalsCoordinateSystem(OWNISO(s))) RETURN_ERR(ERRORWRONGISO);
	  set_dom(PREVSYSOF(sub), s, XONLY);

	  if (fullXdim && !equalsCoordinateSystem(OWNISO(s)) &&
	      SUBNR != CONST) {
	    RETURN_ERR(ERRORWRONGISO);
	  }
 	} else {
	  isotropy_type previso = PREVISO(s);
	  bool kern = equalsKernel(PREVDOM(s));
	  if (isNegDef(type) && // 11.6.19 reaktiviert -- war ausgeblendet
	      ( (kern && (isAnyIsotropic(previso) || isSpaceIsotropic(previso)))
		||
		(!kern && isEarth(previso) && !equalsEarthIsotropic(previso) &&
		 !equalsSphericalIsotropic(previso))
		)) {
	    RETURN_ERR(ERRORWRONGISO);
	  }
	  set_dom(PREVSYSOF(sub), s, OWNDOM(s));
	}
	set_iso(PREVSYSOF(sub), s, OWNISO(s));
      }

      //     A      PMI0(cov);

      // incorrect :
      
      if ((err = CHECK_GEN(sub, SUBMODEL_DEP, SUBMODEL_DEP,
	        	   plus && isPlus(sub) && fullXdim ? LikelihoodType
			   : type == TrendType ? TrendType : frame, //FRAME!!
			   true))
	  == NOERROR) break;

      //      printf("err=%d %s\n", err, TYPE_NAMES[type]);      MER R(err);
      

      // 26.2.19; 13.6. wieder geloescht, da durch CanHaveBoth abgedeckt
      // if ((!isNegDef(type) && !isProcess(type)) || isTrend(type)) break;
 
      //APMI(cov);
      //BUG;
      
      type = TrendType;     
    }

    // printf("mult err = %d %d\n", err, cov->err);
    

    
    if (err != NOERROR) {
      RETURN_ERR(err);
    }

    if (i == 0) {
      setbackward(cov, sub);
      vdim[0] = VDIM0;
      vdim[1] = VDIM1;      
    } else {      
      updatepref(cov, sub);
      //      VDIM0 = sub->vdim[0];
      // VDIM1 = sub->vdim[1];
      cov->randomkappa |= sub->randomkappa;

      bool vdim0ok = vdim[0] == VDIM0;
      if ( !vdim0ok||
	   (vdim[1] != VDIM1 && vdim[1]!=1 && VDIM1 != 1 &&
	    !equalsnowTrend(sub) && !equalsnowTrend(cov->sub[0]))) {
	//	printf("i=%d\n", i);	APMI(cov);
	SERR4("multivariate dimensionality is different in the submodels (%.50s is %d-variate; %.50s is %d-variate)", NICK(cov->sub[0]), cov->vdim[vdim0ok], NICK(sub), vdim[vdim0ok]);
      }
    }
    
    if (false)
      for(int j=0; j<2; j++) {
      if (vdim[j] == 1) {
	if (cov->vdim[j] != 1) vdim[j] = cov->vdim[j];
      } else {
	if (cov->vdim[j] != 1 && cov->vdim[j] != vdim[j])
	  SERR4("multivariate dimensionality is different in the submodels (%.50s is %d-variate; %.50s is %d-variate)", NICK(cov->sub[0]), cov->vdim[j], NICK(sub), vdim[j]);
      }
    }
    /*
    if (i == 0) vdim[0] = VDIM0;
    if (vdim[1] == 1 && VDIM1 != 1) vdim[1] = VDIM1;
    if (i > 0 && (vdim[0] != VDIM0 ||
		  (VDIM1 != 1 && VDIM1 != vdim[1])))
      SERR4("multivariate dimensionality is different in the submodels (%.50s is %d-variate; %.50s is %d-variate)", NICK(cov->sub[0]), cov->sub[0]->vdim[0],
	    NICK(sub), sub->vdim[0]);
    */		  

    cov->matrix_indep_of_x &= sub->matrix_indep_of_x;
    if (conform != NULL)
      conform[i] = !isBad(TypeConsistency(covtype, SUBTYPE(0)));
    // printf("i=%d %d %s: %s %s\n",i, conform[i], NAME(sub),
    //	   TYPE_NAMES[covtype], TYPE_NAMES[SUBTYPE(0)]);
  } // i, nsub
  
  VDIM0 = vdim[0];
  VDIM1 = vdim[1];

  // !! incorrect  !!
  // cov->semiseparatelast = false; 
  //cov->separatelast = false;

  //  printf("plus checked\n");

  RETURN_NOERROR;
}





// see private/old.code/operator.cc for some code including variable locations
void select(double *x, int *info, model *cov, double *v) {
  int len,
    *element = PINT(SELECT_SUBNR);
  model *sub = cov->sub[*element];
  assert(VDIM0 == VDIM1);
  if (*element >= cov->nsub) ERR("select: element out of range");
  COV(x, info, sub, v);
  if ( (len = cov->nrow[SELECT_SUBNR]) > 1) {
    int i, m,
      vdim = VDIM0,
      vsq = vdim * vdim;
    TALLOC_XX1(z, vsq); 
    for (i=1; i<len; i++) {
      sub = cov->sub[element[i]];
      COV(x, info, sub, z);
      for (m=0; m<vsq; m++) v[m] += z[m]; 
    }
    END_TALLOC_XX1;
 }
}
  

void covmatrix_select(model *cov, bool ignore_y, double *v) {
  int len = cov->nrow[SELECT_SUBNR];
  
  if (len == 1) {
    int element = P0INT(SELECT_SUBNR);
    model *next = cov->sub[element];
    if (element >= cov->nsub) ERR("select: element out of range");
    DefList[NEXTNR].covmatrix(next, ignore_y, v);
  } else StandardCovMatrix(cov, ignore_y, v);
}

char iscovmatrix_select(model VARIABLE_IS_NOT_USED *cov) {  return 2; }

int checkselect(model *cov) {
  int err;

  assert(cov->Splus == NULL);

  if (!isCartesian(OWNISO(0))) BUG; // RETURN_ERR(ERRORNOTCARTESIAN);
  kdefault(cov, SELECT_SUBNR, 0);

  int  i,
    nsub = cov->nsub;
  ONCE_NEW_STORAGE(plus);
  ONCE_NEWSTOMODEL;
  bool *conform = cov->Splus->conform;

  if ((err = checkplusmal(cov)) != NOERROR) {
    RETURN_ERR(err);
  }
  
  if (OWNDOM(0) == DOMAIN_MISMATCH) RETURN_ERR(ERRORNOVARIOGRAM);
  if (nsub == 0) cov->pref[SpectralTBM] = PREF_NONE;

  if (isnowPosDef(cov) && isXonly(OWN)) cov->logspeed = 0.0;
  else if (isnowVariogram(cov) && isXonly(OWN)) {
   cov->logspeed = 0.0;
    for (i=0; i<nsub; i++) {
      model *sub = cov->sub[i];
      if (conform[i]) {
	if (ISNAN(sub->logspeed)) {
	  cov->logspeed = RF_NA;
	  break;
	} else cov->logspeed += sub->logspeed;
      }
    }
  } else cov->logspeed = RF_NA;


  if ((err = checkkappas(cov)) != NOERROR) RETURN_ERR(err);

  ONCE_EXTRA_STORAGE;
  RETURN_NOERROR;
}

bool allowedDselect(model *cov) { return allowedDplus(cov); }
bool allowedIselect(model *cov) { return allowedIplus(cov); }


void rangeselect(model VARIABLE_IS_NOT_USED *cov, range_type *range){
  range->min[SELECT_SUBNR] = 0;
  range->max[SELECT_SUBNR] = MAXSUB-1;
  range->pmin[SELECT_SUBNR] = 0;
  range->pmax[SELECT_SUBNR] = MAXSUB-1;
  range->openmin[SELECT_SUBNR] = false;
  range->openmax[SELECT_SUBNR] = false;
}


//int zaehler = 0;
void plus(double *x, int *info, model *cov, double *v){
  model *sub;
  int i, m,
    nsub=cov->nsub,
    vdim = VDIM0,
    vsq = vdim * vdim;
  bool *conform = cov->Splus->conform;

  TALLOC_XX1(z, vsq);

  //printf("vsq=%d\n", vsq);
  // if (zaehler > 20299) printf("cross plus %d %ld\n", zaehler,  v); zaehler++;

  for (m=0; m<vsq; v[m++] = 0.0);
 
  for(i=0; i<nsub; i++) {
    sub = cov->sub[i];    

    if (conform[i]) {
      //printf("i=%d\n", i);
      //PMI(cov);
      //printf("plus i=%d %d %s: %s %s\n",i, conform[i], NAME(sub), TYPE_NAMES[OWNTYPE(0)], TYPE_NAMES[SUBTYPE(0)]);
        
      FCTN(x, info, sub, z);

      //     TREE0(cov);
      //     PMI(cov);
      //  printf("i=%d m=%d %.50s %10g %d %d\n", i,  m, NAME(sub), z[0], sub->vdim[0], vsq); 
      
      if (sub->vdim[0] == 1) for (m=0; m<vsq; m++) v[m] += z[0]; 
      else for (m=0; m<vsq; m++) v[m] += z[m];
      //printf("%% %d\n", i);
    }
    // if (!R_FINITE(v[0]) || !R_FINITE(v[1]) || !R_FINITE(v[2]) || !R_FINITE(v[3])) { PMI(sub); printf("\n\nplus i=%d m=%d x=%10g %10g %10g\n", i, m, x[0], v[0], z[0]);    printf("(%4.3f, %4.3f; %4.3e %4.3e %4.3e %4.3e)\t", x[0], x[1], v[0], v[1], v[2], v[3]);BUG; }
    //APMI(cov->calling);
   // 
  }

  END_TALLOC_XX1;
}

void nonstat_plus(double *x, double *y, int *info, model *cov, double *v){
  model *sub;
  int i, m,
    nsub=cov->nsub,
    vsq = VDIM0 * VDIM1;
  bool *conform = cov->Splus->conform;
  assert(VDIM0 == VDIM1);
  TALLOC_XX1(z, vsq);
  for (m=0; m<vsq; v[m++] = 0.0);
  for(i=0; i<nsub; i++) {
    sub = cov->sub[i];
    if (conform[i]) {
      //printf("nonstat plus i=%d %d %s: %s %s\n",i, conform[i], NAME(sub),
      //       TYPE_NAMES[OWNTYPE(0)], TYPE_NAMES[SUBTYPE(0)]);
  
      //   if (Type Consistency(cov->typus, sub->typus)) {
      NONSTATCOV(x, y, info, sub, z);
      if (sub->vdim[0] == 1) for (m=0; m<vsq; m++) v[m] += z[0]; 
      else for (m=0; m<vsq; m++) v[m] += z[m]; 
    }
  }
  END_TALLOC_XX1;
}

void Dplus(double *x, int *info, model *cov, double *v){
  model *sub;
  int nsub = cov->nsub, i,
    vsq = VDIM0 * VDIM1;
  bool *conform = cov->Splus->conform;
  TALLOC_XX1(z, vsq);
  for (int m=0; m<vsq; v[m++] = 0.0);
  for (i=0; i<nsub; i++) { 
    sub = cov->sub[i];
    if (conform[i]) {
      Abl1(x, info, sub, z);
      if (sub->vdim[0] == 1) for (int m=0; m<vsq; m++) v[m] += z[0]; 
      else for (int m=0; m<vsq; m++) v[m] += z[m]; 
    }
  }
  END_TALLOC_XX1;
}

void DDplus(double *x, int *info, model *cov, double *v){
  model *sub;
  int nsub = cov->nsub, i,
    vsq = VDIM0 * VDIM1;
  bool *conform = cov->Splus->conform;
  TALLOC_XX1(z, vsq);
  for (int m=0; m<vsq; v[m++] = 0.0);
  for (i=0; i<nsub; i++) { 
    sub = cov->sub[i];
   if (conform[i]) {
     Abl2(x, info, sub, z);
      if (sub->vdim[0] == 1) for (int m=0; m<vsq; m++) v[m] += z[0]; 
      else for (int m=0; m<vsq; m++) v[m] += z[m]; 
    }
  }
  END_TALLOC_XX1;
}


int checkplus(model *cov) {

  //printf("\n************************** Entering checkplus %d\n", cov->zaehler);
  
  int err, 
    nsub = cov->nsub;
  ONCE_NEW_STORAGE(plus);
  bool *conform = cov->Splus->conform;
  model *sub = cov->sub[0];

  
  //if (cov->nsub == 1) {
  //  printf("nsub=%d, %d  %d\n", cov->nsub  , isPlus(sub),
  //	   (PisNULL(PLUS_TREND)));
  //PMI0(sub);}
  
  if (cov->nsub == 1 && isPlus(sub) && sub->ownloc == NULL &&
      (PisNULL(PLUS_TREND) || PARAMisNULL(sub, PLUS_TREND) ||
       PARAM0INT(sub, PLUS_TREND) ==  P0INT(PLUS_TREND))) {
    
    for (int i=0; i<sub->nsub; i++) {
      cov->sub[i] = sub->sub[i];
      cov->sub[i]->calling = cov;
    }
    cov->nsub = sub->nsub;
    if (!PARAMisNULL(sub, PLUS_TREND))
      kdefault(cov, PLUS_TREND, PARAM0INT(sub, PLUS_TREND));
    COV_DELETE_WITHOUTSUB(&sub, cov); // OK, da sub->ownloc == NULL
  }

  if (!equalsShape(PREVTYPE(0)) // was danach kommt is alles ok.
      && !PisNULL(PLUS_TREND) && (P0INT(PLUS_TREND) xor isnowTrend(cov)))  {
    //    printf("%d %d %d\n", P0INT(PLUS_TREND), isnowTrend(cov),
    //    (P0INT(PLUS_TREND) xor isnowTrend(cov)));
    //    PMI(cov);  
    SERR1("Summands are forced to be trends, but calling model '%.20s' does not require a shape function", cov->calling == NULL ? "<none>" : NICK(cov->calling));

  }
  if (OWNDOM(0) == DOMAIN_MISMATCH) RETURN_ERR(ERRORNOVARIOGRAM);
  if (nsub == 0) cov->pref[SpectralTBM] = PREF_NONE;
  if (cov->Sextra == NULL) {
    if (!PisNULL(PLUS_TREND)) {
      bool trend = P0INT(PLUS_TREND);
      for (int i=0; i<cov->nsub; i++) {
	model *m = cov->sub[i];
	if (isPlus(m)) kdefault(m, PLUS_TREND, trend);
      }
    }
    ONCE_EXTRA_STORAGE;
  }
     
  if ((err = checkplusmal(cov)) != NOERROR) RETURN_ERR(err);
  if (isnowPosDef(cov) && isXonly(OWN)) cov->logspeed = 0.0;
  else if (isnowVariogram(cov) && isXonly(OWN)) {
   cov->logspeed = 0.0;
    for (int i=0; i<nsub; i++) {
      sub = cov->sub[i];
      if (conform[i]) {
	if (ISNAN(sub->logspeed)) {
	  cov->logspeed = RF_NA;
	  break;
	} else cov->logspeed += sub->logspeed;
      }
    }
  } else cov->logspeed = RF_NA;

  if ((err = checkkappas(cov, false)) != NOERROR) RETURN_ERR(err);
  
  RETURN_NOERROR;

  // spectral mit "+" funktioniert, falls alle varianzen gleich sind,
  // d.h. nachfolgend DOLLAR die Varianzen gleich sind oder DOLLAR nicht
  // auftritt; dann zufaellige Auswahl unter "+"
}

void rangeplus(model VARIABLE_IS_NOT_USED *cov, range_type *range){
  booleanRange(PLUS_TREND);
}




bool allowedDplus(model *cov) {
  //assert(COVNR == MULT);
  model **sub = cov->sub;
  if (MODELKEYS_GIVEN) {
    GETSTOMODEL;
    sub = STOMODEL->keys;
  }

  bool *D = cov->allowedD;
  int nsub = MAXSUB, // cov->nsub,
    j=0,
    idx = (int) FIRST_DOMAIN;

  while (true) {
    while (j<nsub && sub[j] == NULL) j++;
    if (j >= nsub) return allowedDtrue(cov);
    if (!allowedD(sub[j])) break;
    j++;
  }
  MEMCOPY(D, sub[j]->allowedD, sizeof(allowedD_type));

  while (idx <= (int) LAST_DOMAINUSER && !D[idx]) idx++;
  // printf("allowedDPlus idx = %d %d %d\n", idx, LAST_DOMAINUSER, CanHaveBothTrendAndCov(cov));
  assert(idx <= (int) LAST_DOMAINUSER);
  if (idx == (int) LAST_DOMAINUSER) return false;
  if (CanHaveBothTrendAndCov(cov)) {    
    if (equalsXonly((domain_type) idx)) D[KERNEL] = true;
    return false;
  }
  
  for (j++; j<nsub; j++) {
    if (sub[j] == NULL) continue;
    if (allowedD(sub[j])) continue;
    bool *subD = sub[j]->allowedD;
    int subDidx = FIRST_DOMAIN;
    while (subDidx <= (int) LAST_DOMAINUSER && !subD[subDidx]) subDidx++;
    assert(subDidx <= (int) LAST_DOMAINUSER);
    for (; idx < subDidx; D[idx++] = false);
    for (int i = idx; i<=(int) LAST_DOMAINUSER; i++) D[i] |= subD[i];
    if (idx == (int) LAST_DOMAINUSER) return false;
  }

  
  
  return false;
}


bool allowedIplus(model *cov) {
  //  printf("entering allowedIplus\n");
  bool *I = cov->allowedI;
  if (CanHaveBothTrendAndCov(cov)) {
    //printf("can have both\n");
    for(int i=FIRST_ISOUSER; i<= LAST_ISOUSER; i++) I[i] = false;
    if (LocDist(cov) && LocxdimOZ(cov) == 1)
      I[ISOTROPIC] = I[SPHERICAL_ISOTROPIC] = I[EARTH_ISOTROPIC] = true;
    else {
      isotropy_type previso = CONDPREVISO(0); 
      if(isFixed(previso)) I[previso] = true;
      else I[CARTESIAN_COORD] = I[SPHERICAL_COORD] = I[EARTH_COORD] = true;
    }
    return false;
  }
  //ssert(COVNR == MULT);
 
  model *sub[MAXSUB]; // llowedIsubs schreibt hier hinein!
  int nsub = cov->nsub,
   z = 0;
  model **Sub=cov->sub;
  if (MODELKEYS_GIVEN) {
    GETSTOMODEL;
    Sub = STOMODEL->keys;
  }
  for (int i=0; z<nsub; i++) if (Sub[i]!=NULL) sub[z++] = Sub[i];
  
  assert(z == nsub); // wenn nicht schlimm -- also nur bei mir testen
  bool allowed = allowedIsubs(cov, sub, z);
  if (COVNR == PLUS) {
    if (LocDist(cov) && LocxdimOZ(cov) == 1) 
      I[ISOTROPIC] = I[SPHERICAL_ISOTROPIC] = I[EARTH_ISOTROPIC] = true;
    else {
      isotropy_type previso = CONDPREVISO(0); 
      if (isFixed(previso)) I[previso] = true;
      else I[CARTESIAN_COORD] = I[SPHERICAL_COORD] = I[EARTH_COORD] = true;
    }
  }
  return allowed;
}


//int Zaehler = 0;

Types Typeplus(Types required, model *cov, isotropy_type required_iso) {
  //  assert(false);
  bool allowed = isShape(required) || isTrend(required) ||
    equalsRandom(required);
    //||required==ProcessType ||required==GaussMethodType; not yet allowed;to do
 
  if (!allowed) return BadType;

  // printf("here %.50s %d\n", NAME(cov), ++Zaehler);
 
  if (isManifold(required)) { // nue 6.8.17
    BUG;
    int last = PREVLASTSYSTEM;
    for (int s=1; s<=last; s++)
      if (!isSameAsPrev(PREVTYPE(s))) {
	// to do : not programmed yet
	//	printf("FAILED! %.50s %d\n", NAME(cov), Zaehler);
	return BadType;
      }
    
    //   printf("RETURNING %.50s %d\n", NAME(cov), Zaehler);
    return TypeConsistency(PREVTYPE(0), cov, required_iso);
  }

  int nsub = cov->nsub;
  for (int i=0; i<nsub; i++) {
    //   print("i=%d %.50s\n", i, NAME(cov->sub[i]));
    if (!isBad(TypeConsistency(required, cov->sub[i], required_iso)))
      return required;
    //   print("i not ok\n");
  }
  
  // printf("FAILED %.50s %d\n", NAME(cov), Zaehler);
  return BadType;
}

void spectralplus(model *cov, gen_storage *s, double *e){
  assert(VDIM0 == 1);
  int nr;
  double dummy;
  spectral_storage *cs = &(s->Sspectral);
  double *var_cum = cs->sub_var_cum; // UNKLAR: SD ODER VAR ?? 12.3.19

  nr = cov->nsub - 1;
  dummy = UNIFORM_RANDOM * var_cum[nr];
  if (ISNAN(dummy)) BUG;
  while (nr > 0 && dummy <= var_cum[nr - 1]) nr--;
  model *sub = cov->sub[nr];
  SPECTRAL(sub, s, e);  // nicht gatternr
}


int structplus(model *cov, model VARIABLE_IS_NOT_USED **newmodel){
  int err;  
  switch(cov->frame) {
  case EvaluationType :  RETURN_NOERROR; // VariogramType vor 11.1.19
  case GaussMethodType : {
    if (isnowProcess(cov)) {
      assert(COVNR != PLUS_PROC);
      assert(COVNR == PLUS);
      //COVNR = PLUS_PROC;
      BUG;
      //return structplusproc(cov, newmodel); // kein S-TRUCT !!
    }
    if (MODELKEYS_GIVEN) BUG;
    int nsub = cov->nsub;
    for (int m=0; m<nsub; m++) {
      model *sub = cov->sub[m];
      if ((err = STRUCT(sub, newmodel))  > NOERROR) {
	RETURN_ERR(err);
      }
    }
  }
    break;
  default :
    SERR2("frame '%.50s' not allowed for '%.50s'", TYPE_NAMES[cov->frame],
	  NICK(cov));
  }
  RETURN_NOERROR;
}


int initplus(model *cov, gen_storage *s){
  GETSTOMODEL;
   int err,
    vdim = VDIM0;
  if (VDIM0 != VDIM1) BUG; // ??

  int maxv = MIN(vdim, MAXMPPVDIM);
  for (int i=0; i<maxv; i++) cov->mpp.maxheights[i] = RF_NA;

  if (hasGaussMethodFrame(cov)) {
    spectral_storage *cs = &(s->Sspectral);
    double *var_cum = cs->sub_var_cum;
 
    if (VDIM0 == 1) {
      int nsub = cov->nsub;
      for (int i=0; i<nsub; i++) {
	model *sub = !MODELKEYS_GIVEN
	  ? cov->sub[i] : STOMODEL->keys[i];
	
	assert(sub != NULL);
	if (sub->pref[Nothing] > PREF_NONE) { // to do ??
	  // for spectral plus only
	  AtZero(sub, var_cum + i);
	  if (i>0) var_cum[i] += var_cum[i-1];
	}
	NEW_COV_STORAGE(cov->sub[i], gen);
	if ((err = INIT(sub, cov->mpp.moments, s)) != NOERROR) {
	  //  AERR(err);
	  RETURN_ERR(err);
	}
	sub->simu.active = true;
      }
    } 
 
    cov->fieldreturn = (ext_bool) (MODELKEYS_GIVEN);
    cov->origrf = false;
    if (cov->fieldreturn) cov->rf = STOMODEL->keys[0]->rf;
     
    RETURN_NOERROR;
  }

  else if (hasAnyEvaluationFrame(cov)) {
    int nsub = cov->nsub;
    for (int i=0; i<nsub; i++) {
      // e.g. truncsupport( .. + ...) with parts being random
      model *sub = !MODELKEYS_GIVEN
	? cov->sub[i] : STOMODEL->keys[i];
      assert(sub != NULL);
      // printf("%s randomkappa=%d moment=%d\n", NAME(sub), sub->randomkappa,cov->mpp.moments);
      if (sub->randomkappa &&
	  (err = INIT(sub, cov->mpp.moments, s)) != NOERROR) {
	//  AERR(err);
	RETURN_ERR(err);
      }
    }      
    RETURN_NOERROR;
  }

  RETURN_ERR(ERRORFAILED);
}


void doplus(model *cov, gen_storage *s) {
  int nsub = cov->nsub;
  GETSTOMODEL;
   
  if (hasGaussMethodFrame(cov) && cov->method==SpectralTBM) {
    ERR("error in doplus with spectral");
  }
  
  for (int i=0; i<nsub; i++) {
    model *sub = MODELKEYS_GIVEN
      ? STOMODEL->keys[i] : cov->sub[i];
    if (sub->randomkappa || isnowRandom(sub)) { // 15.3.19 
      DO(sub, s);
    } // else assert(Defn[MODELNR(sub)]->Do 
  }
}




void covmatrix_plus(model *cov, bool ignore_y, double *v) {
  //  defn *C = DefList + COVNR; // nicht gatternr
  Long
    totalpoints = LoctotalpointsY(cov, ignore_y),
    vdimtot = totalpoints * VDIM0,
    vdimtotSq = vdimtot * vdimtot;
  int
    nsub = cov->nsub;
  bool is = iscovmatrix_plus(cov) >= 2;

  if (is) {
    TALLOC_X1(mem, vdimtotSq);// da sowieso hoffnungslos
    // Bei der Berechnung der einzelnen Kovarianzmatrizen, muss darauf
    // geachtet werden, dass u.U. Koord-Trafos stattfinden. Somit
    // wird selectnr aufgerufen
    int nr = 0;
    model *next = cov->sub[nr];
    if (LoctotalpointsY(next, ignore_y) != totalpoints) BUG;
    DefList[NEXTNR].covmatrix(next, ignore_y, v);
    for (nr=1; nr<nsub; nr++) {
      next = cov->sub[nr];
      if (LoctotalpointsY(next, ignore_y) != totalpoints) BUG;
      DefList[NEXTNR].covmatrix(next, ignore_y, mem);
      for (int j=0; j<vdimtotSq; j++) v[j] += mem[j];
    }
    END_TALLOC_X1;
  }
  StandardCovMatrix(cov, ignore_y, v);
}

char iscovmatrix_plus(model *cov) {
  char max=2, is; // 0
  int nsub = cov->nsub;
  for (int i=0; i<nsub; i++) {
    model *sub = cov->sub[i];
    is = DefList[SUBNR].is_covmatrix(sub);
    if (is < max) max = is; // > 
  }
  return max;
}


void mal(double *x, int* info, model *cov, double *v){
  model *sub;
  int 
    nsub=cov->nsub,
    vdim = VDIM0,
    vsq = vdim * vdim;
  TALLOC_XX1(z, vsq);
  
  //  assert(x[0] >= 0.0 || OWNXDIM(0) > 1);
  for (int m=0; m<vsq; v[m++] = 1.0);
  for(int i=0; i<nsub; i++) {
    sub = cov->sub[i];
    COV(x, info, sub, z);
    if (sub->vdim[0] == 1) for (int m=0; m<vsq; m++) v[m] *= z[0];
    else for (int m=0; m<vsq; m++) v[m] *= z[m];  
  }
  END_TALLOC_XX1;
}

void logmal(double *x, int *info, model *cov, double *v, double *Sign){
  model *sub;
  int 
    nsub=cov->nsub,
    vdim = VDIM0,
    vsq = vdim * vdim;
  TALLOC_XX1(z, vsq);
  TALLOC_XX2(zSign, vsq);

  assert(VDIM0 == VDIM1); 
  assert(x[0] >= 0.0 || OWNTOTALXDIM > 1);
  for (int m=0; m<vsq; m++) {v[m] = 0.0; Sign[m]=1.0;}
  for(int i=0; i<nsub; i++) {
    sub = cov->sub[i];
    LOGCOV(x, info, sub, z, zSign);
    if (sub->vdim[0] == 1) {
      for (int m=0; m<vsq; m++) {
	v[m] += z[0]; 
	Sign[m] *= zSign[0];
      }
    } else {
      for (int m=0; m<vsq; m++) {
	v[m] += z[m]; 
	Sign[m] *= zSign[m];
      }
    }
  }
  END_TALLOC_XX1;
  END_TALLOC_XX2;
}

void nonstat_mal(double *x, double *y, int* info, model *cov, double *v){
  model *sub;
  int nsub=cov->nsub,
    vdim = VDIM0,
    vsq = vdim * vdim;
  TALLOC_XX1(z, vsq);

  assert(VDIM0 == VDIM1);
  assert(VDIM0 == VDIM1);

  for (int m=0; m<vsq; m++) v[m] = 1.0;
  for(int i=0; i<nsub; i++) {
    sub = cov->sub[i];
    NONSTATCOV(x, y, info, sub, z);
    if (sub->vdim[0] == 1) for (int m=0; m<vsq; m++) v[m] *= z[0];
    else for (int m=0; m<vsq; m++) v[m] *= z[m];  
  }
  END_TALLOC_XX1;
}

void nonstat_logmal(double *x, double *y, int *info, model *cov, double *v, 
		    double *Sign){
  model *sub;
  int  nsub=cov->nsub,
    vdim = VDIM0,
    vsq = vdim * vdim;
  assert(VDIM0 == VDIM1);
  TALLOC_XX1(z, vsq);
  TALLOC_XX2(zSign, vsq);
  for (int m=0; m<vsq; m++) {v[m] = 0.0; Sign[m]=1.0;}
  for(int i=0; i<nsub; i++) {
    sub = cov->sub[i];
    LOGNONSTATCOV(x, y, info, sub, z, zSign);
    if (sub->vdim[0] == 1) {
      for (int m=0; m<vsq; m++) {
	v[m] += z[0]; 
	Sign[m] *= zSign[0];
      }
    } else {
      for (int m=0; m<vsq; m++) {
	v[m] += z[m]; 
	Sign[m] *= zSign[m];
      }
    }
  }
  END_TALLOC_XX1;
  END_TALLOC_XX2;
}

void Dmal(double *x, int* info, model *cov, double *v){
  model *sub;
  int nsub = cov->nsub, 
    vsq = VDIM0 * VDIM1;
  TALLOC_XXX1(c, vsq * nsub);
  TALLOC_XXX2(d, vsq * nsub);

  for (int i=0; i<nsub; i++) {
    sub = cov->sub[i];
    COV(x, info, sub, c + i * vsq);
    Abl1(x, info, sub, d + i * vsq);
  }
  *v = 0.0;
  for (int i=0; i<nsub; i++) {
    double *zw = d + i *vsq;
    int j;
    for (j=0; j<nsub; j++) {
      double *cc = c + j * vsq;
      if (j!=i) {
	for (int k=0; k<vsq; k++) zw[j] *= cc[j]; 
      }
    }
    for (int k=0; k<vsq; k++) v[k] += zw[k];
  }
  END_TALLOC_XXX1;
  END_TALLOC_XXX2;
}


int checkmal(model *cov) {
  //  PMI0(cov);  printf("check mal");
  model *next1 = cov->sub[0];
  model *next2 = cov->sub[1];
  int err,
    nsub = cov->nsub;

  if (next2 == NULL) next2 = next1;
  if ((err = checkplusmal(cov)) != NOERROR) {
    RETURN_ERR(err);
  }

  bool ok = OWNDOM(0) != DOMAIN_MISMATCH &&
    (equalsnowTrend(cov) || equalsnowRandom(cov) ||
     (isnowShape(cov) && (!isnowNegDef(cov) || isnowPosDef(cov) )));
  if (!ok) RETURN_ERR(ERRORNOVARIOGRAM);
   
  // to do istcftype und allgemeiner typ zulassen
  if (equalsnowTrend(cov)) {
    model *calling = cov->calling;
    if (calling!=NULL && isPlus(calling) &&!PARAMisNULL(calling, PLUS_TREND)) {
      if (!PARAM0INT(calling, PLUS_TREND)) BUG;
    } else {
      ok = false;
      for (int i=0; i<nsub; i++) {
	int nr = MODELNR(cov->sub[i]);
	if ((ok =  nr == CONST || nr == BIND)) break;
      }
      if (!ok) SERR2("misuse as a trend function. At least one factor must be a constant (including 'NA') or a vector built with '%.50s(...)' or '%.50s(...).",
		     DefList[BIND].name,  DefList[BIND].nick);
    }
  }
  cov->logspeed = isXonly(OWN) ? 0 : RF_NA;
      

  if (OWNTOTALXDIM >= 2) cov->pref[TBM] = PREF_NONE;
  if (OWNTOTALXDIM==2 && nsub == 2 && 
      isAnyDollar(next1) && isAnyDollar(next2)) {
    double *aniso1 = PARAM(next1, DANISO),
      *aniso2 = PARAM(next2, DANISO);
    if (aniso1 != NULL && aniso2 != NULL) {
      if (aniso1[0] == 0.0 && next1->ncol[DANISO] == 1) {
	cov->pref[TBM] = next2->pref[TBM];
      } else if (aniso2[0] == 0.0 && next2->ncol[DANISO] == 1) {
	cov->pref[TBM] = next1->pref[TBM];
      }
    }
  }
  
  if (cov->ptwise_definite == pt_submodeldep) {
    cov->ptwise_definite = next1->ptwise_definite;
    if (cov->ptwise_definite != pt_zero) {
      for (int i=1; i<nsub; i++) {
	model *sub = cov->sub[i];
	if (sub->ptwise_definite == pt_zero) {
	  cov->ptwise_definite = pt_zero;
	  break;
	}
	if (sub->ptwise_definite != pt_posdef) {
	  if (sub->ptwise_definite == pt_negdef) {
	    cov->ptwise_definite = 
	      cov->ptwise_definite == pt_posdef ? pt_negdef
	      : cov->ptwise_definite == pt_negdef ? pt_posdef
	      : pt_indef;
	  } else { // sub = indef
	    cov->ptwise_definite = sub->ptwise_definite;
	    break;
	  }
	}
      }
    }
  }
	  
  ONCE_EXTRA_STORAGE;
  RETURN_NOERROR;
}



Types Typemal(Types required, model *cov, isotropy_type required_iso){
  bool allowed = isShape(required) || isTrend(required) ||
    equalsRandom(required);
  //||required==ProcessType ||required==GaussMethodType; not yet allowed;to do
  if (!allowed) return BadType;
  int nsub = cov->nsub;
  for (int i=0; i<nsub; i++) {
    if (isBad(TypeConsistency(required, cov->sub[i], required_iso)))
      return BadType;
  }
  return required;
}




int structmal(model *cov, model VARIABLE_IS_NOT_USED **newmodel){
  //  int m, err;  
  switch(cov->frame) {
  case EvaluationType :  RETURN_NOERROR; // VariogramType vor 11.1.19
  case GaussMethodType : RETURN_ERR(ERRORFAILED);
  default :
    SERR2("frame '%.50s' not allowed for '%.50s'", TYPE_NAMES[cov->frame],
	  NICK(cov));
  }
  RETURN_NOERROR;
}


int initmal(model *cov, gen_storage *s){
  // PMI0(cov);  printf("init mal");
  int err,
    nsub = cov->nsub,
    vdim = VDIM0;
  if (VDIM0 != VDIM1) BUG; // ??

  //  if (cov->Smodel == NULL) crash();
  GETSTOMODEL;
 
  int maxv = MIN(vdim, MAXMPPVDIM);
  for (int i=0; i<maxv; i++)cov->mpp.maxheights[i] = RF_NA;

  if (hasGaussMethodFrame(cov)) {
    // spectral_storage *cs = &(s->Sspectral); 
    if (VDIM0 == 1) {
      for (int i=0; i<nsub; i++) {
	model *sub = !MODELKEYS_GIVEN
	  ? cov->sub[i] : STOMODEL->keys[i];
	assert(sub != NULL);
	if ((err = INIT(sub, cov->mpp.moments, s)) != NOERROR) {
	  //  AERR(err);
	  RETURN_ERR(err);
	}
      }
    }
 
    cov->fieldreturn = falsch;
    cov->origrf = false;
     
    RETURN_NOERROR;
  }

  else if (hasAnyEvaluationFrame(cov)) {
    for (int i=0; i<nsub; i++) {
      // e.g. truncsupport( .. + ...) with parts being random
      model *sub = !MODELKEYS_GIVEN
	? cov->sub[i] : STOMODEL->keys[i];
      assert(sub != NULL);
      // printf("%s randomkappa=%d moment=%d\n", NAME(sub), sub->randomkappa,cov->mpp.moments);
      if (sub->randomkappa &&
	  (err = INIT(sub, cov->mpp.moments, s)) != NOERROR) {
	//  AERR(err);
	RETURN_ERR(err);
      }
    }
  }
  RETURN_NOERROR;
}

void domal(model VARIABLE_IS_NOT_USED *cov,
	   gen_storage VARIABLE_IS_NOT_USED *s){
  if (hasGaussMethodFrame(cov) && cov->method==SpectralTBM) {
    ERR("error in 'domal' with spectral");
  }

  GETSTOMODEL;
   int nsub = cov->nsub;
  for (int i=0; i<nsub; i++) {
    model *sub = MODELKEYS_GIVEN
      ? STOMODEL->keys[i] : cov->sub[i];
    if (sub->randomkappa || isnowRandom(sub)) { // 15.3.19 
      DO(sub, s);
    } // else assert(Defn[MODELNR(sub)]->Do 
  }
}



//////////////////////////////////////////////////////////////////////
// mpp-plus


#define PLUS_P 0 // parameter
int  CheckAndSetP(model *cov){   
  int
    nsub = cov->nsub;
  double 
    cump = 0.0;
  if (PisNULL(PLUS_P)) {
    assert(cov->nrow[PLUS_P] == 0 && cov->ncol[PLUS_P] == 0);
    PALLOC(PLUS_P, nsub, 1);
    for (int i=0; i<nsub; i++) P(PLUS_P)[i] = 1.0 / (double) nsub;    
  } else {
    cump = 0.0;
    for(int i = 0; i<nsub; i++) {
      cump += P(PLUS_P)[i];
      if (cump > 1.0 && i+1<nsub) RETURN_ERR(ERRORATOMP);
    }
    if (cump != 1.0) {
      if (nsub == 1) {
	WARN0("the p-values do not sum up to 1.\nHere only one p-value is given which must be 1.0");
	P(PLUS_P)[0] = 1.0;
      } else {
	if (cump < 1.0 && P(PLUS_P)[nsub-1] == 0) {
	  WARN1("The value of the last component of '%.50s' is increased.",
		KNAME(PLUS_P)); 

	}
	else SERR1("The components of '%.50s' do not sum up to 1.", KNAME(PLUS_P));
	P(PLUS_P)[nsub-1] = 1.0 - (cump - P(PLUS_P)[nsub-1]);
      }  
    }
  }
  RETURN_NOERROR;
}

void kappamppplus(int i, model *cov, int *nr, int *nc){
  *nr = cov->nsub;
  *nc = i < DefList[COVNR].kappas ? 1 : -1;
}

void mppplus(double *x, int *info, model *cov, double *v) { 
  int
    nsub = cov->nsub,
    vdim = VDIM0,
    vdimSq = vdim * vdim;
  model *sub;
  TALLOC_XX1(z, vdimSq);

  if (hasAnyEvaluationFrame(cov)) {  
    for (int m=0; m<vdimSq; m++) v[m] = 0.0;
    for (int n=0; n<nsub; n++, sub++) {
      sub = cov->sub[n];
      COV(x, info, sub, z); // urspruenglich : covlist[sub].cov(x, cov, z); ?!
      for (int i=0; i<vdimSq; i++) v[i] += P(PLUS_P)[n] * z[i];
    }
  } else {
    assert(hasPoissonFrame(cov));
    BUG;
  }
  END_TALLOC_XX1;
}

int checkmppplus(model *cov) { 
  ASSERT_ONESYSTEM;
  int err, 
    size = 1;
  
  SERR("the current version does not support RMmppplus\n");
  set_maxdim(OWN, 0, MAXMPPDIM);

  if ((err = checkplusmal(cov)) != NOERROR) {
    RETURN_ERR(err);
  }

  if ((err = CheckAndSetP(cov)) != NOERROR) RETURN_ERR(err);

  if (cov->q == NULL) QALLOC(size);
  ONCE_EXTRA_STORAGE;
  RETURN_NOERROR;
}


void rangempplus(model VARIABLE_IS_NOT_USED *cov, range_type *range){ 
  range->min[PLUS_P] = 0.0;
  range->max[PLUS_P] = 1.0;
  range->pmin[PLUS_P] = 0.0;
  range->pmax[PLUS_P] = 1.0;
  range->openmin[PLUS_P] = false;
  range->openmax[PLUS_P] = false;
}

int struct_mppplus(model *cov, model **newmodel){
  int 
    //nsub = cov->nsub,
    err = NOERROR;
  
  if (!hasMaxStableFrame(cov) && !hasPoissonFrame(cov)) {
    SERR("method is not based on Poisson point process");
  }


  RETURN_ERR(ERRORNOTPROGRAMMEDYET);

  
  // Ausnahme: mppplus wird separat behandelt:
  // if (nr == MPPPLUS) return S TRUCT(shape, NULL);
 
  ASSERT_NEWMODEL_NOT_NULL;
  NEW_STORAGE(plus);
  NEW_STORAGE(pgs);
  NEWSTOMODEL;
  GETSTOMODEL;

  int nsub = cov->nsub;
  for (int i=0; i<nsub; i++) {
    model *sub = cov->sub[i];
    if (STOMODEL->keys[i] != NULL) COV_DELETE(STOMODEL->keys + i, cov);    
    if ((err = covcpy(STOMODEL->keys + i, sub)) != NOERROR) RETURN_ERR(err);
    if ((err = addShapeFct(STOMODEL->keys + i)) != NOERROR) RETURN_ERR(err);
    SET_CALLING(STOMODEL->keys[i], cov);
  }
  RETURN_NOERROR;
}


int init_mppplus(model *cov, gen_storage *S) {
  model  *sub;
  double M2[MAXMPPVDIM], M2plus[MAXMPPVDIM], Eplus[MAXMPPVDIM], 
    maxheight[MAXMPPVDIM];
  int n, err,
    vdim = VDIM0;
  if (VDIM0 != VDIM1) BUG;
  if (vdim > MAXMPPVDIM) BUG;
  int maxv = MIN(vdim, MAXMPPVDIM);
  for (int i=0; i<maxv; i++) {
    maxheight[i] = RF_NEGINF; // maxv
    M2[i] = M2plus[i] = Eplus[i] = 0.0;
  }
    
  GETSTOMODEL;
  pgs_storage *pgs = cov->Spgs;
  pgs->totalmass = 0.0;
  
  // loggiven could depend on the realasation; this is determined here
  // in case the different submodels have different values for loggiven
  // formerly loggiven got the value SUBMODEL_DEP. Now, it gets the
  // value false
  cov->loggiven = wahr; 
  assert(cov->nsub > 0);
  for (n=0; n<cov->nsub; n++) {
    sub = cov->sub[n];
    //if (!sub->mpp.loc_done) 
    //SERR1("submodel %d of '++': the location of the shapes isn't defined", 
    // n);
    if ((err = INIT(sub, cov->mpp.moments, S)) != NOERROR) RETURN_ERR(err);
    //if (!sub->mpp.loc_done) SERR("locations are not initialised");

    if (cov->loggiven != falsch)      // at least 1 non-loggiven
      cov->loggiven = sub->loggiven;  //  leads to non-loggiven
    if (n==0) cov->fieldreturn = sub->fieldreturn;
    else if (cov->fieldreturn != sub->fieldreturn) 
      cov->fieldreturn = (ext_bool) SUBMODEL_DEP;

    pgs->totalmass += sub->Spgs->totalmass * P(PLUS_P)[n];
    for (int i=0; i<maxv; i++)
       if (cov->mpp.maxheights[i] > maxheight[i])  // maxv
	 maxheight[i] = cov->mpp.maxheights[i]; // maxv
     //  loggiven &= cov->loggiven;

    // Achtung cov->mpp.mM2 und Eplus koennten nicht direkt gesetzt
    // werden, da sie vom DefList[SUBNR].Init ueberschrieben werden !!
    
    if (cov->mpp.moments >= 1) {
      int nmP1 = sub->mpp.moments + 1;
      for (int i=0; i<vdim; i++) {
	int idx = i * nmP1;
	Eplus[i] += PARAM0(sub, PLUS_P) * sub->mpp.mMplus[idx + 1]; 
      }
      if (cov->mpp.moments >= 2) {
	for (int i=0; i<vdim; i++) {
	  int idx = i * nmP1;
	  M2[i] += PARAM0(sub, PLUS_P)  * sub->mpp.mM[idx + 2];
	  M2plus[i] += PARAM0(sub, PLUS_P) * sub->mpp.mM[idx + 2];
	}
      }
    }
    //assert(sub->mpp.loc_done);
  }

  for (int i=0; i<maxv; i++) cov->mpp.maxheights[i] = maxheight[i];
  //cov->mpp.refsd = RF_NA;
  //  cov->mpp.refradius = RF_NA;

  
  if (cov->mpp.moments >= 1) {
    int nmP1 = cov->mpp.moments + 1;
    for (int i=0; i<vdim; i++) {
      int idx = i * nmP1;
      cov->mpp.mMplus[idx + 1] = Eplus[i];
      cov->mpp.mM[idx + 1] = RF_NA;
    }
    if (cov->mpp.moments >= 2) {
      for (int i=0; i<vdim; i++) {
	 int idx = i * nmP1;
	 cov->mpp.mM[idx + 2] = M2[i];
	 cov->mpp.mMplus[idx + 2] = M2plus[i];
      }
    }
  }
  
  //  cov->loggiven = loggiven;
  // cov->fieldreturn = fieldreturn;
  //cov->mpp.loc_done = true;       
  cov->origrf = false;
  cov->rf = NULL;

  RETURN_NOERROR;
}

void do_mppplus(model *cov, gen_storage *s) {
  model *sub;
  double subselect = UNIFORM_RANDOM;
  int subnr,
    vdim = VDIM0;
  assert(VDIM0 == VDIM1);
  for (subnr=0; (subselect -= PARAM0(cov->sub[subnr], PLUS_P)) > 0; subnr++);
  cov->q[0] = (double) subnr; // wofuer???
  sub = cov->sub[subnr];
  
  DefList[SUBNR].Do(sub, s);  // nicht gatternr
  int maxv = MIN(vdim, MAXMPPVDIM);
  for (int i=0; i<maxv; i++) cov->mpp.maxheights[i] = sub->mpp.maxheights[i];
  cov->fieldreturn = sub->fieldreturn;
  cov->loggiven = sub->loggiven;
}

//////////////////////////////////////////////////////////////////////
// PROCESSES
//////////////////////////////////////////////////////////////////////


int checkplusmalproc(model *cov) {
  model *sub;
  int err,
    nsub = cov->nsub;
  GETSTOMODEL;
  
  assert(MODELKEYS_GIVEN);
  
  for (int i=0; i<nsub; i++) {

    sub = STOMODEL->keys[i];
    
    if (sub == NULL) 
      SERR("named submodels are not given in a sequence.");

    Types type = isTrend(sub) ? ProcessType : OWNTYPE(0); // sollte ok sein.

    
    assert(equalsCoordinateSystem(OWNISO(0)));
    
    if ((err = CHECK_THROUGHOUT(sub, cov, type, KEEPCOPY_DOM, KEEPCOPY_ISO,
				SUBMODEL_DEP, cov->frame)) != NOERROR) {
     //   if ((err= CHECK(sub, dim, xdim, type, dom, iso, SUBMODEL_DEP, frame))
     //	!= NOERROR) {
     
      
      if ((cov->calling == NULL || cov->calling->calling == NULL) &&
	  isSymmetric(OWNISO(0)) && isVariogram(OWNTYPE(0))) {
	err = CHECK_THROUGHOUT(sub, cov, type, KEEPCOPY_DOM, 
			       CoordinateSystemOf(OWNISO(0)),
			       SUBMODEL_DEP, cov->frame);
      }
      if (err != NOERROR) RETURN_ERR(err);
    }
   
    if (!isnowProcess(sub) && !equalsnowTrend(sub))
      SERR2("neither negative definite, nor process nor trend nor the calling type %.20s from %.20s", TYPE_NAMES[type], NICK(cov));
    if (i==0) {
      VDIM0=sub->vdim[0];  // to do: inkonsistent mit vorigen Zeilen !!
      VDIM1=sub->vdim[1];  // to do: inkonsistent mit vorigen Zeilen !!
    } else {
      if (VDIM0 != sub->vdim[0] || VDIM1 != sub->vdim[1]) {
	SERR("multivariate dimensionality must be equal in the submodels");
      }
    }
  }

  RETURN_NOERROR;
}



int checkplusproc(model *cov) {
  int err;

  if ((err = checkplusmalproc(cov)) != NOERROR) {
    RETURN_ERR(err);
  }

  ONCE_EXTRA_STORAGE;
  RETURN_NOERROR;
}


int structplusmalproc(model *cov, model VARIABLE_IS_NOT_USED**newmodel){
  int //dim =  PREVXDIM(0),
    err;
  switch(cov->frame) {
  case GaussMethodType : {
    ONCE_NEW_STORAGE(plus);
    ONCE_NEWSTOMODEL;
    getStorage(s ,     plus);
    GETSTOMODEL;
    STOMODEL->keys_given = true;
    int nsub = cov->nsub;
    for (int m=0; m<nsub; m++) {
      model *sub = cov->sub[m];
      bool trend = isnowTrend(sub);
      if (STOMODEL->keys[m] != NULL) COV_DELETE(STOMODEL->keys + m, cov);
      if ((err =  covcpy(STOMODEL->keys + m, sub)) != NOERROR) {
	RETURN_ERR(err);
      }


      //      PMI(cov);

      
      assert(STOMODEL->keys[m] != NULL);
      assert(STOMODEL->keys[m]->calling == cov);
      
      if (PL >= PL_STRUCTURE) {
	LPRINT("plus: trying initialisation of submodel #%d (%s).\n", m+1, 
	       NICK(sub));
      }

      addModelX(STOMODEL->keys + m, trend ? SHAPE_FCT_PROC : GAUSSPROC);
     
      //printf("isTrend = %d %s\n", isTrend(sub), NAME(sub));

      // 14.11.20 : unklar ob folgendes noch benoetigt wird !!
      // vorallem in Zshg mit trend !!
      //     if (trend && sub->Spgs == NULL) {
      //	if ((err = alloc_cov(sub, dim, sub->vdim[0], sub->vdim[1])) != NOERROR)
      //	  RETURN_ERR(err);
      // }

      SET_CALLING(STOMODEL->keys[m], cov);

      
#if MAXSYSTEMS > 1    
      COPYALLSYSTEMS(PREVSYSOF(sub), OWN, false);
      int last = OWNLASTSYSTEM;
      for (int ss=0; ss<=last; ss++) {
      	BUG;
      }
#endif

      //PMI0(cov); 
      int tsdim = Loctsdim(cov);
      if ((err = CHECK(STOMODEL->keys[m], tsdim, tsdim,
		       trend ? ProcessType: OWNTYPE(0), XONLY,
		       PREVISO(0), 
		       cov->vdim,
		       GaussMethodType)) != NOERROR) {
	RETURN_ERR(err);
      }
    
      if ((err = STRUCT(STOMODEL->keys[m], NULL))  > NOERROR) RETURN_ERR(err);
      
    }
    
    RETURN_NOERROR;
  }
    
  default :
    SERR2("frame '%.50s' not allowed for '%.50s'", TYPE_NAMES[cov->frame],
	  NICK(cov));
  }

  RETURN_NOERROR;
}


int structplusproc(model *cov, model **newmodel){
  assert(COVNR == PLUS_PROC);
  return structplusmalproc(cov, newmodel);
}


int structmultproc(model *cov, model **newmodel){
  assert(DefList[COVNR].check == checkmultproc);
  return structplusmalproc(cov, newmodel);
}

int initplusmalproc(model *cov, gen_storage VARIABLE_IS_NOT_USED *s){
  int  err,
    nsub = cov->nsub,
    vdim = VDIM0;
  assert(VDIM0 == VDIM1);
  bool plus = COVNR == PLUS_PROC ;
 GETSTOMODEL;

  int maxv = MIN(vdim, MAXMPPVDIM);
  for (int i=0; i<maxv; i++) cov->mpp.maxheights[i] = RF_NA;
  if (!MODELKEYS_GIVEN) BUG;

  if (hasGaussMethodFrame(cov)) {
 
    for (int i=0; i<nsub; i++) {
      model *sub = MODELKEYS_GIVEN
	? STOMODEL->keys[i] : cov->sub[i];
      if (!plus && 
	  (SUBNR == CONST 
	   //|| DefList[sub[0]->nr].check == checkconstant ||
	   // (isDollar(sub) && DefList[sub->sub[0]->nr].check == checkconstant)
	   ))
	continue;
      assert(cov->sub[i]->Sgen==NULL);
      NEW_COV_STORAGE(cov->sub[i], gen);
      if ((err = INIT(sub, 0, cov->sub[i]->Sgen)) != NOERROR) {
	RETURN_ERR(err);
      }
      sub->simu.active = true;
    }
    cov->simu.active = true;
    RETURN_NOERROR;
  }
    
  else {
    BUG;
  }

  RETURN_ERR(ERRORFAILED);
}

 
int initplusproc(model *cov, gen_storage VARIABLE_IS_NOT_USED *s){
  GETSTOMODEL;
 int err;
 if ((err = initplusmalproc(cov, s)) != NOERROR) RETURN_ERR(err);

  if (hasGaussMethodFrame(cov)) {
    cov->fieldreturn = (ext_bool) (MODELKEYS_GIVEN);
    cov->origrf = false;
    assert(cov->fieldreturn);
    if (cov->fieldreturn) cov->rf = STOMODEL->keys[0]->rf;
     
    RETURN_NOERROR;
  }
     
  else {
    BUG;
  }

  RETURN_ERR(ERRORFAILED);
}


void doplusproc(model *cov, gen_storage VARIABLE_IS_NOT_USED *s) {
 GETSTOMODEL;
  int
    nsub = cov->nsub,
    total = Loc(cov)->totalpoints * VDIM0;
  double *res = cov->rf;
  assert(cov->rf == STOMODEL->keys[0]->rf);
  assert(VDIM0 == VDIM1);

  if (hasGaussMethodFrame(cov) && cov->method==SpectralTBM) {
    ERR("error in doplus with spectral");
  }
  assert(MODELKEYS_GIVEN);

  for (int m=0; m<nsub; m++) {
    model *key = STOMODEL->keys[m],
      *sub = cov->sub[m];
    double *keyrf = key->rf;
    DO(key, sub->Sgen);
    if (m > 0) for(int i=0; i<total; i++) res[i] += keyrf[i];
  }
  return;
}



#define MULTPROC_COPIES 0
int checkmultproc(model *cov) {
  option_type *global = &(cov->base->global);
  int err;
  kdefault(cov, MULTPROC_COPIES, global->special.multcopies);
  if ((err = checkplusmalproc(cov)) != NOERROR) {
    RETURN_ERR(err);
  }

  ONCE_EXTRA_STORAGE;
  RETURN_NOERROR;
}


int initmultproc(model *cov, gen_storage VARIABLE_IS_NOT_USED *s){
  int  err;

  if ((err = initplusmalproc(cov, s)) != NOERROR) {
    BUG;
   RETURN_ERR(err);
  }

  if (hasGaussMethodFrame(cov)) {
    ReturnOwnField(cov);
    RETURN_NOERROR;
  }
     
  else {
    BUG;
  }

  RETURN_ERR(ERRORFAILED);
}




void domultproc(model *cov, gen_storage VARIABLE_IS_NOT_USED *s) {
  option_type *global = &(cov->base->global);
  double *res = cov->rf;
  assert(VDIM0 == VDIM1);
  int idx,
    nsub = cov->nsub,
    vdim = VDIM0,
   //  vdimSq= vdim * vdim,
    total = Loc(cov)->totalpoints,
   totalvdim = total * vdim,
   copies = global->special.multcopies,
   factors = 0;
 GETSTOMODEL;

  if (hasGaussMethodFrame(cov) && cov->method==SpectralTBM) {
    ERR("error in do_mult with spectral");
  }
  
  if (nsub==2) {
    int m0 = MODELNR(cov->sub[0]),
      m1 = MODELNR(cov->sub[1]);      
    if (((m0 == PROD_PROC) xor (idx = m1==PROD_PROC))
	&& m0 != CONST &&  m1 != CONST) {
   // koennte noch allgemeiner gemacht werden in verbindung mit CONST; todo
      copies = 1;
      assert(cov->sub[idx]->qlen > PRODPROC_RANDOM);
      cov->sub[idx]->q[PRODPROC_RANDOM] = (double) false;
    }
  }

  assert(MODELKEYS_GIVEN);
  TALLOC_X1(z, totalvdim); // da eh hoffnungslos

  SAVE_GAUSS_TRAFO;
  for (int c=0; c<copies; c++) {
    for(int i=0; i<totalvdim; res[i++] = 1.0);
    for (int m=0; m<nsub; m++) {

      if (PL > PL_RECURSIVE) {
	PRINTF("\rcopies=%d sub=%d\n", c, m);
      }

      model *key = STOMODEL->keys[m],
	*sub = cov->sub[m];
      double *keyrf = key->rf;
      if (SUBNR == CONST) {
	double 
	  cc = isnowTrend(sub) ? PARAM0(sub, CONST_C) 
	  : SQRT(PARAM0(sub, CONST_C));
	for(int i=0; i<totalvdim; i++) res[i] *= cc;
	//printf("cc=%10g\n", cc);
      }
      /* else {
	bool dollar = isDollar(sub);
	model *Const = dollar ? Const->sub[0] : sub;
	if (DefList[Check->nr].check == checkconstant) {
	  if (dollar) {
	    double var = PARAM0(sub, DVAR);
	    bool random = false;
	    if (sub->kappasub[DVAR] != NULL) {
	      if (random = is Random(sub->kappasub[DVAR])) {
		Do(sub->kappasub[DVAR], sub->Sgen);
	      } else {
		TA LLOC_EXTRA2(VarMem, totalvdim);
		F ct n(NULL, sub->kappasub[DVAR], VarMem);
	      }
	    }
	    if (var != 1.0) {
	      double sd = SQRT(var);
	      for(i=0; i<totalvdim; i++) res[i] *= sd;
	    }
	  } else {
	  TA LLOC_EXT RA3(ConstMem, vdimSq);
	  }
	  } */
      else {	  
	factors ++;
	DO(key, sub->Sgen);
	for(int i=0; i<totalvdim; i++){
	  res[i] *= keyrf[i];

	  //if (!R_finite(keyrf[i]) || (i < 2 && keyrf[i] != 0.0 && FABS(keyrf[i]) < 1e-308))  printf("c=%d, m=%d i =%d,  %e\n",  c, m, i, keyrf[i]);
	  
	}
      }
    }
    if (factors == 1) return; // no Error, just exit
    if (c == 0) res = z;
    else for(int i=0; i<totalvdim; i++) {
	//if (!R_finite(res[i]) || (i < 2 && res[i] != 0.0 && FABS(res[i]) < 1e-308)) printf("c=%d, i =%d,  %e\n",  c, i, res[i]);
	cov->rf[i] += res[i];
      }
    //    if (cov->rf != NULL) printf("mult :: %e %e\n", cov->rf[0], cov->rf[1]);  else printf("mlt cov->rf == NULL");
  }

  double f;
  f = 1 / SQRT((double) copies);
  //printf("f=%10g\n", f);
  for(int i=0; i<totalvdim; i++) cov->rf[i] *= f;

  END_TALLOC_X1;
  //  printf("mult done %e %e\n", cov->rf[0], cov->rf[1]);
}



void rangemultproc(model VARIABLE_IS_NOT_USED *cov, range_type* range){
  range->min[MULTPROC_COPIES] = 1.0;
  range->max[MULTPROC_COPIES] = RF_INF;
  range->pmin[MULTPROC_COPIES] = 1.0;
  range->pmax[MULTPROC_COPIES] = 1000;
  range->openmin[MULTPROC_COPIES] = false;
  range->openmax[MULTPROC_COPIES] = true;
}


// $power

void PowS(double *x, int *info, model *cov, double *v){
  logPowS(x, info, cov, v, NULL);
}

void logPowS(double *x, int *info, model *cov, double *v, double *Sign){
  model *next = cov->sub[POW_SUB];
  double 
    factor,
    var = P0(POWVAR),
    scale =P0(POWSCALE), 
    p = P0(POWPOWER),
    invscale = 1.0 / scale;
  int i,
    vdim = VDIM0,
    vdimSq = vdim *vdim,
    xdimown = OWNXDIM(0);
  assert(VDIM0 == VDIM1);
  TALLOC_X1(z, xdimown);

  for (i=0; i < xdimown; i++) z[i] = invscale * x[i];
  if (Sign==NULL) {
    COV(z, info, next, v);
    factor = var * POW(scale, p);
    for (i=0; i<vdimSq; i++) v[i] *= factor; 
  } else {
    LOGCOV(z, info, next, v, Sign);
    factor = LOG(var) + p * LOG(scale);
    for (i=0; i<vdimSq; i++) v[i] += factor; 
  }
  END_TALLOC_X1;
}

void nonstatPowS(double *x, double *y, int *info, model *cov, double *v){
  nonstat_logPowS(x, y, info, cov, v, NULL);
}

void nonstat_logPowS(double *x, double *y, int *info, model *cov, double *v, 
		 double *Sign){
  model *next = cov->sub[POW_SUB];
  double 
    factor,
    var = P0(POWVAR),
    scale =P0(POWSCALE), 
    p = P0(POWPOWER),
     invscale = 1.0 / scale;
  int i,
    vdim = VDIM0,
    vdimSq = vdim * vdim,
    xdimown = OWNXDIM(0);
  assert(VDIM0 == VDIM1);
  TALLOC_X1(z1, xdimown);
  TALLOC_X2(z2, xdimown);

  for (i=0; i<xdimown; i++) {
    z1[i] = invscale * x[i];
    z2[i] = invscale * y[i];
  }

  if (Sign==NULL) {
    NONSTATCOV(z1, z2, info, next, v);
    factor = var * POW(scale, p);
    for (i=0; i<vdimSq; i++) v[i] *= factor; 
  } else {
    LOGNONSTATCOV(z1, z2, info, next, v, Sign);
    factor = LOG(var) + p * LOG(scale);
    for (i=0; i<vdimSq; i++) v[i] += factor; 
  }
  END_TALLOC_X1;
  END_TALLOC_X2;
}

 
void inversePowS(double *x, model *cov, double *v) {
  model *next = cov->sub[POW_SUB];
  int i,
    vdim = VDIM0,
    vdimSq = vdim * vdim;
  double y, 
    scale =P0(POWSCALE),
    p = P0(POWPOWER),
    var = P0(POWVAR);
 assert(VDIM0 == VDIM1);

  y = *x / (var * POW(scale, p)); // inversion, so variance becomes scale
  if (DefList[NEXTNR].inverse == inverseErr) BUG;
  INVERSE(&y, next, v);
 
  for (i=0; i<vdimSq; i++) v[i] *= scale; 
}

void inversenonstatPowS(double *x, model *cov, double *left, double *right) {
  model *next = cov->sub[0];
  int dim = PREVTOTALXDIM;
  if (dim != OWNTOTALXDIM) BUG;
  double s = P0(POWSCALE),
    y = POW(*x, -s);
  INVERSENONSTAT(&y, next, left, right);
  for (int d=0 ; d<dim; d++) {
    left[d] *= s;
    right[d] *= s;
  }
}


int TaylorPowS(model *cov) {
  if (VDIM0 != 1) SERR("Taylor only known in the unvariate case");
  model 
    *next = cov->sub[POW_SUB];
  int i;
  double scale = PisNULL(POWSCALE) ? 1.0 : P0(POWSCALE);
  cov->taylorN = next->taylorN;  
  for (i=0; i<cov->taylorN; i++) {
    cov->taylor[i][TaylorPow] = next->taylor[i][TaylorPow];
    cov->taylor[i][TaylorConst] = next->taylor[i][TaylorConst] *
      P0(POWVAR) * POW(scale, P0(POWPOWER) - next->taylor[i][TaylorPow]);   
  }
  
  cov->tailN = next->tailN;  
  for (i=0; i<cov->tailN; i++) {
    cov->tail[i][TaylorPow] = next->tail[i][TaylorPow];
    cov->tail[i][TaylorExpPow] = next->tail[i][TaylorExpPow];
    cov->tail[i][TaylorConst] = next->tail[i][TaylorConst] *
      P0(POWVAR) * POW(scale, P0(POWPOWER) - next->tail[i][TaylorPow]);   
    cov->tail[i][TaylorExpConst] = next->tail[i][TaylorExpConst] *
      POW(scale, -next->tail[i][TaylorExpPow]);
  }
  RETURN_NOERROR;
}


int checkPowS(model *cov) {
  // hier kommt unerwartet  ein scale == nan rein ?!!
  model 
    *next = cov->sub[POW_SUB];
  int err, 
    dim = OWNLOGDIM(0),
    xdimown = OWNXDIM(0),
    xdimNeu = xdimown;

  if (!isCartesian(OWNISO(0))) RETURN_ERR(ERRORNOTCARTESIAN);
    
  kdefault(cov, POWVAR, 1.0);
  kdefault(cov, POWSCALE, 1.0);
  kdefault(cov, POWPOWER, 0.0);
  if ((err = checkkappas(cov)) != NOERROR) {
    RETURN_ERR(err);
  }
  
  ASSERT_ONESYSTEM;
  if ((err = CHECK(next, dim, xdimNeu, OWNTYPE(0), OWNDOM(0),
		   OWNISO(0), SUBMODEL_DEP, cov->frame)) != NOERROR) {
    RETURN_ERR(err);
  }

  setbackward(cov, next);
  if ((err = TaylorPowS(cov)) != NOERROR) RETURN_ERR(err);

  ONCE_EXTRA_STORAGE;
  RETURN_NOERROR;
}



Types TypePowS(Types required, model *cov, isotropy_type required_iso){
 bool allowed = isShape(required) || isTrend(required) ||
   equalsRandom(required);
    //||required==ProcessType ||required==GaussMethodType; not yet allowed;to do
  if (!allowed) return BadType;

  model *next = cov->sub[0];
  return TypeConsistency(required, next, required_iso);
}


void rangePowS(model *cov, range_type* range){
  range->min[POWVAR] = 0.0;
  range->max[POWVAR] = RF_INF;
  range->pmin[POWVAR] = 0.0;
  range->pmax[POWVAR] = 100000;
  range->openmin[POWVAR] = false;
  range->openmax[POWVAR] = true;

  range->min[POWSCALE] = 0.0;
  range->max[POWSCALE] = RF_INF;
  range->pmin[POWSCALE] = 0.0001;
  range->pmax[POWSCALE] = 10000;
  range->openmin[POWSCALE] = true;
  range->openmax[POWSCALE] = true;

   int dim = OWNLOGDIM(0);
 range->min[POWPOWER] = RF_NEGINF;
  range->max[POWPOWER] = RF_INF;
  range->pmin[POWPOWER] = -dim;
  range->pmax[POWPOWER] = +dim;
  range->openmin[POWPOWER] = true;
  range->openmax[POWPOWER] = true;
 }



void PowScaleToLoc(model *to, model *from, int VARIABLE_IS_NOT_USED depth) {
  assert(!PARAMisNULL(to, LOC_SCALE) && !PARAMisNULL(from, POWSCALE));
  PARAM(to, LOC_SCALE)[0] = PARAM0(from, POWSCALE);
}

int structPowS(model *cov, model **newmodel) {
  model
    *next = cov->sub[POW_SUB],
    *scale = cov->kappasub[POWSCALE];
  int err; 

  if (next->randomkappa) SERR("random shapes not programmed yet");

  switch (cov->frame) {
  case SmithType :  case GaussMethodType :
    ASSERT_NEWMODEL_NOT_NULL;
    
    if ((err = STRUCT(next, newmodel)) > NOERROR) RETURN_ERR(err);
    
    addModel(newmodel, POWER_DOLLAR, cov);
    if (!PisNULL(POWVAR)) kdefault(*newmodel, POWVAR, P0(POWVAR));
    if (!PisNULL(POWSCALE)) kdefault(*newmodel, POWSCALE, P0(POWSCALE));
    if (!PisNULL(POWPOWER)) kdefault(*newmodel, POWPOWER, P0(POWPOWER));
    
    break;
  case BrMethodType : case SchlatherType : {
    ASSERT_NEWMODEL_NOT_NULL;
    
    if ((err = STRUCT(next, newmodel)) > NOERROR) RETURN_ERR(err);
    
    if (!isnowRandom(scale)) SERR("unstationary scale not allowed yet");
    addModel(newmodel, LOC, cov);
    addSetDistr(newmodel, scale, PowScaleToLoc, true, MAXINT);
  }
    break;
  default :
    SERR2("'%.50s': changes in scale/variance not programmed yet for '%.50s'", 
	  NICK(cov), TYPE_NAMES[cov->frame]);      
  }  
   
  RETURN_NOERROR;
}




int initPowS(model *cov, gen_storage *s){
  // am liebsten wuerde ich hier die Koordinaten transformieren;
  // zu grosser Nachteil ist dass GetDiameter nach trafo 
  // grid def nicht mehr ausnutzen kann -- umgehbar?!
  model *next = cov->sub[POW_SUB],
    *Var = cov->kappasub[POWVAR],
    *Scale = cov->kappasub[POWSCALE];
  int 
    vdim = VDIM0,
    nm = cov->mpp.moments,
    nmvdim = (nm + 1) * vdim,
    err = NOERROR;
  bool 
    maxstable = hasMaxStableFrame(cov);// Realisationsweise 
  assert(VDIM0 == VDIM1);


  assert(cov->key == NULL || ({PMI(cov);false;}));//   
  
  if (maxstable) { // !! ohne maxstable selbst !!
    double
      var[MAXMPPVDIM],  
      p = P0(POWPOWER),
      scale = P0(POWSCALE);
    int 
      intp = (int) p,
      dim = OWNLOGDIM(0);


    // Achtung I-NIT_RANDOM ueberschreibt mpp.* !!
    if (Var != NULL) {
      int nm_neu = nm == 0 && !maxstable ? 1 : nm;
      if ((err = INIT_RANDOM(Var, nm_neu, s, P(POWVAR))) != NOERROR) 
	RETURN_ERR(err);
      int nmP1 = Var->mpp.moments + 1;
      for (int i=0; i<vdim; i++) {
	int idx = i * nmP1;
	var[i] = maxstable ? P0(POWVAR) : Var->mpp.mM[idx + 1];
      }
    } else for (int i=0; i<vdim; i++) var[i++] = P0(POWVAR);
 
    if (Scale != NULL) {
      if (p != intp)
	SERR1("random scale can be initialised only for integer values of '%.50s'",
	     KNAME(POWPOWER));
      if (dim + intp < 0) SERR("negative power cannot be calculated yet");
      int idx_s = maxstable ? nm : dim + nm + intp < 1 ? 1 : dim + nm + intp;
      if ((err = INIT_RANDOM(Scale, idx_s, s, P(POWSCALE))) != NOERROR)
	RETURN_ERR(err);
      assert(Scale->mpp.moments == 1);
      scale = maxstable ? P0(DSCALE) : Scale->mpp.mM[1];
    }
    if ((err = INIT(next, nm, s)) != NOERROR) RETURN_ERR(err);


    for (int i=0; i < nmvdim; i++) {
      cov->mpp.mM[i] = next->mpp.mM[i];
      cov->mpp.mMplus[i] = next->mpp.mMplus[i];
   }


    if (Var != NULL && !maxstable) {
      int j,
	nmP1 = Var->mpp.moments + 1;
      for (j=0; j<vdim; j++) {
	int idx = j * nmP1;
	for (int i=0; i <= nm; i++) {
	  cov->mpp.mM[i] *= Var->mpp.mM[idx + i];
	  cov->mpp.mMplus[i] *= Var->mpp.mMplus[idx + i];
	}
      }
    } else {
      int j, k;
      double pow_var;
      for (k=j=0; j<vdim; j++) { 
	pow_var = 1.0;
	for (int i=0; i<=nm; i++, pow_var *= var[j], k++) {	
	  cov->mpp.mM[k] *= pow_var;
	  cov->mpp.mMplus[k] *= pow_var;
	}
      }
    }

    if (Scale != NULL && !maxstable) {
      if (dim + nm * intp < 0 || dim + intp * nm > Scale->mpp.moments) 
	SERR("moments cannot be calculated");
      assert(Scale->vdim[0] == 1 && Scale->vdim[1] == 1 );
      for (int i=0; i <= nm; i++) {
	int idx = dim + i * intp;
	cov->mpp.mM[i] *= Scale->mpp.mM[idx];
	cov->mpp.mMplus[i] *= Scale->mpp.mMplus[idx];
      }
    } else {
      int j,k;
      double 
	pow_scale,
	pow_s = POW(scale, dim),
	pow_p = POW(scale, p);
      for (k=j=0; j<vdim; j++) { 
	pow_scale = pow_s;
	for (int i=0; i <= nm; i++, pow_scale *= pow_p, k++) {
	  cov->mpp.mM[k] *= pow_scale;
	  cov->mpp.mMplus[k] *= pow_scale;
	}
      }
    }

    bool unnormed = R_FINITE(next->mpp.unnormedmass);
    if (unnormed) {
      if (vdim > 1) BUG;
      cov->mpp.unnormedmass =
	next->mpp.unnormedmass * (var[0] * POW(scale, p + dim));
    } else cov->mpp.unnormedmass = RF_NAN;
    
    if (Scale != NULL || isnowRandom(next)) {
      if (unnormed) {
	int maxv = MIN(vdim, MAXMPPVDIM);
	for (int i=0; i<maxv; i++) cov->mpp.maxheights[i] = RF_INF;
      } else RETURN_ERR(ERRORNOTPROGRAMMEDYET);
    } else {
      double pp = POW(scale, p);
      int maxv = MIN(vdim, MAXMPPVDIM);
      for (int i=0; i<maxv; i++) 
	cov->mpp.maxheights[i] = next->mpp.maxheights[i] * (var[i] * pp);//maxv
    }
  }
  

  else if (hasGaussMethodFrame(cov)) {
    if ((err=INIT(next, 0, s)) != NOERROR) RETURN_ERR(err);
  }

  //  else if (cov->frame = = Any Type) {
  //    if ((err=INIT(next, 0, s)) != NOERROR) RETURN_ERR(err);    
  //  }

  else SERR("Initiation of scale and/or variance failed");

 
  if ((err = TaylorPowS(cov)) != NOERROR) RETURN_ERR(err);

  RETURN_NOERROR;
}


void doPowS(model *cov, gen_storage *s){
 
  if (hasMaxStableFrame(cov)) {
    model *next = cov->sub[POW_SUB];
         
    DO(next, s);// nicht gatternr
    double factor = P0(POWVAR) * POW(P0(POWSCALE), P0(POWPOWER));
    int vdim = VDIM0;
    assert(VDIM0 == VDIM1);
    int maxv = MIN(vdim, MAXMPPVDIM);
    for (int i=0; i<maxv; i++)
      cov->mpp.maxheights[i] = next->mpp.maxheights[i] * factor; // maxv
    return;
  } 
 
  BUG;
}
 
