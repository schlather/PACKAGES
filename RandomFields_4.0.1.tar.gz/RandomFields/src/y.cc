
#include <General_utils.h>
void crash() {  
  BUG;
}

